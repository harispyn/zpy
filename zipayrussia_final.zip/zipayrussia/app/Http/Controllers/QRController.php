<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use GuzzleHttp\Client;
use Illuminate\Support\Facades\Session;

class QRController extends Controller
{
    public function process(Request $request)
    {
        $validated = $request->validate([
            'qrCode' => 'required|string',
        ]);

        // Ambil data user dari session (bukan auth()->user() karena app ini session-based)
        $userData = Session::get('api_response');

        if (!$userData || !isset($userData['phoneNumber'])) {
            return response()->json(['error' => 'User not authenticated'], 401);
        }

        $client = new Client();

        try {
            $response = $client->post(config('services.multipocket.base_url') . '/api/Qris/IssuerScan', [
                'headers' => [
                    'Accept' => 'application/json',
                    'Content-Type' => 'application/json-patch+json',
                ],
                'json' => [
                    'qrCode'        => $validated['qrCode'],
                    'phoneNumber'   => $userData['phoneNumber'],
                    'mid'           => config('services.multipocket.mid'),
                    'merchantToken' => config('services.multipocket.merchant_token'),
                ],
            ]);

            return response()->json(json_decode($response->getBody()->getContents(), true));

        } catch (\GuzzleHttp\Exception\ClientException $e) {
            $statusCode   = $e->getResponse()->getStatusCode();
            $errorMessage = json_decode($e->getResponse()->getBody()->getContents(), true);

            return response()->json([
                'error'   => $errorMessage['message'] ?? 'QR processing failed',
                'code'    => $statusCode,
            ], $statusCode);

        } catch (\Exception $e) {
            return response()->json([
                'error' => 'Unexpected error: ' . $e->getMessage(),
            ], 500);
        }
    }
}
