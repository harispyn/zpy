<?php

use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;
use App\Http\Middleware\CheckApiToken;
use App\Http\Middleware\SetLocale;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware) {
        // Daftarkan alias middleware untuk digunakan di routes
        $middleware->alias([
            'checkApiToken' => CheckApiToken::class,
            'setLocale'     => SetLocale::class,
        ]);

        // Middleware 'guest' sudah built-in di Laravel,
        // middleware 'admin' perlu didefinisikan atau dihapus jika tidak dipakai
    })
    ->withExceptions(function (Exceptions $exceptions) {
        //
    })->create();
