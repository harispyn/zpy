@extends('layouts.app')
@section('title', 'Auto Lock')
@section('content')
<div class="preload preload-container"><div class="preload-logo"><div class="spinner"></div></div></div>
<div class="header mb-1 is-fixed">
    <div class="tf-container">
        <div class="tf-statusbar d-flex justify-content-center align-items-center">
            <a href="{{ route('settings') }}" class="back-btn"><i class="icon-left"></i></a>
            <h3>Auto Lock</h3>
        </div>
    </div>
</div>
<div class="mt-5">
    <div class="tf-container">
        <ul class="box-settings-profile">
            <li><a href="#" class="list-setting-profile"><p>Immediately</p></a></li>
            <li><a href="#" class="list-setting-profile"><p>After 1 minute</p></a></li>
            <li><a href="#" class="list-setting-profile"><p>After 5 minutes</p></a></li>
            <li><a href="#" class="list-setting-profile"><p>After 30 minutes</p></a></li>
            <li><a href="#" class="list-setting-profile"><p>Never</p></a></li>
        </ul>
        <a href="{{ route('settings') }}" class="tf-btn accent large mt-3">Back to Settings</a>
    </div>
</div>
@endsection
