@extends('layouts.app')
@section('title', 'Change Password')
@section('content')
<div class="preload preload-container"><div class="preload-logo"><div class="spinner"></div></div></div>
<div class="header mb-1 is-fixed">
    <div class="tf-container">
        <div class="tf-statusbar d-flex justify-content-center align-items-center">
            <a href="{{ route('settings') }}" class="back-btn"><i class="icon-left"></i></a>
            <h3>Change Password</h3>
        </div>
    </div>
</div>
<div class="mt-5">
    <div class="tf-container">
        <p class="text-center text-muted">Change password via forgot password.</p>
        <a href="{{ route('reset.password') }}" class="tf-btn accent large mt-3">Reset Password</a>
    </div>
</div>
@endsection
