@extends('layouts.app')
@section('title', 'Language')
@section('content')
<div class="preload preload-container"><div class="preload-logo"><div class="spinner"></div></div></div>
<div class="header mb-1 is-fixed">
    <div class="tf-container">
        <div class="tf-statusbar d-flex justify-content-center align-items-center">
            <a href="{{ route('settings') }}" class="back-btn"><i class="icon-left"></i></a>
            <h3>Language</h3>
        </div>
    </div>
</div>
<div class="mt-5">
    <div class="tf-container">
        <ul class="box-settings-profile">
            <li>
                <a href="{{ url()->current() }}?lang=en" class="list-setting-profile">
                    <p>🇬🇧 English</p>
                    @if(app()->getLocale() == 'en')<i class="icon-check"></i>@endif
                </a>
            </li>
            <li>
                <a href="{{ url()->current() }}?lang=id" class="list-setting-profile">
                    <p>🇮🇩 Bahasa Indonesia</p>
                    @if(app()->getLocale() == 'id')<i class="icon-check"></i>@endif
                </a>
            </li>
            <li>
                <a href="{{ url()->current() }}?lang=ru" class="list-setting-profile">
                    <p>🇷🇺 Русский</p>
                    @if(app()->getLocale() == 'ru')<i class="icon-check"></i>@endif
                </a>
            </li>
        </ul>
        <a href="{{ route('settings') }}" class="tf-btn accent large mt-3">Back to Settings</a>
    </div>
</div>
@endsection
