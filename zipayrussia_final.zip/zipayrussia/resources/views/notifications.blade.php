@extends('layouts.app')
@section('title', 'Notification Settings')
@section('content')
<div class="preload preload-container"><div class="preload-logo"><div class="spinner"></div></div></div>
<div class="header mb-1 is-fixed">
    <div class="tf-container">
        <div class="tf-statusbar d-flex justify-content-center align-items-center">
            <a href="{{ route('settings') }}" class="back-btn"><i class="icon-left"></i></a>
            <h3>Notifications</h3>
        </div>
    </div>
</div>
<div class="mt-5">
    <div class="tf-container">
        <div class="list-setting-profile">
            <div class="inner-left"><h4 class="fw_6">Push Notifications</h4></div>
            <a href="#" class="inner-right">
                <input class="tf-switch-check" type="checkbox" value="checkbox" name="push_notif" checked>
            </a>
        </div>
        <a href="{{ route('settings') }}" class="tf-btn accent large mt-3">Back to Settings</a>
    </div>
</div>
@endsection
