@extends('layouts.app')
@section('title', 'Account Balance')
@section('content')
<div class="preload preload-container"><div class="preload-logo"><div class="spinner"></div></div></div>
<div class="header mb-1 is-fixed">
    <div class="tf-container">
        <div class="tf-statusbar d-flex justify-content-center align-items-center">
            <a href="{{ route('profile') }}" class="back-btn"><i class="icon-left"></i></a>
            <h3>Account Balance</h3>
        </div>
    </div>
</div>
<div class="mt-5">
    <div class="tf-container">
        <div class="tf-balance-box text-center p-4">
            <p>Your Balance</p>
            <h2 class="fw_8">—</h2>
            <a href="{{ route('home') }}" class="tf-btn accent large mt-3">Go to Home</a>
        </div>
    </div>
</div>
@endsection
