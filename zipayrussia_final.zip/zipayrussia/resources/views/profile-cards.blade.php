@extends('layouts.app')
@section('title', 'Cards & Bank Accounts')
@section('content')
<div class="preload preload-container"><div class="preload-logo"><div class="spinner"></div></div></div>
<div class="header mb-1 is-fixed">
    <div class="tf-container">
        <div class="tf-statusbar d-flex justify-content-center align-items-center">
            <a href="{{ route('profile') }}" class="back-btn"><i class="icon-left"></i></a>
            <h3>Cards &amp; Bank Accounts</h3>
        </div>
    </div>
</div>
<div class="mt-5">
    <div class="tf-container">
        <p class="text-center text-muted">No cards or bank accounts linked.</p>
        <a href="{{ route('profile') }}" class="tf-btn accent large mt-3">Back to Profile</a>
    </div>
</div>
@endsection
