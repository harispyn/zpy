@extends('layouts.app')
@section('title', 'My QR Code')
@section('content')
<div class="preload preload-container"><div class="preload-logo"><div class="spinner"></div></div></div>
<div class="header mb-1 is-fixed">
    <div class="tf-container">
        <div class="tf-statusbar d-flex justify-content-center align-items-center">
            <a href="{{ route('profile') }}" class="back-btn"><i class="icon-left"></i></a>
            <h3>My QR Code</h3>
        </div>
    </div>
</div>
<div class="wrap-qr mt-5">
    <div class="tf-container text-center">
        <h2 class="fw_6">My QR Code</h2>
        <div class="logo-qr mt-3">
            <img src="{{ asset('images/scan-qr/qrcode1.png') }}" alt="QR Code" style="max-width:220px;">
        </div>
        <p class="mt-3 text-muted">Show this QR code to receive money</p>
        <a href="{{ route('profile') }}" class="tf-btn accent large mt-3">Back</a>
    </div>
</div>
@endsection
