<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8"/>
    <meta content="IE=edge" http-equiv="X-UA-Compatible"/>
    <!-- Mobile Specific Metas -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, viewport-fit=cover" name="viewport"/>
    <title>Zipay Russian Wallet - <?php echo $__env->yieldContent('title', ''); ?></title>
    <!-- Favicon and Touch Icons -->
    <link href="<?php echo e(asset('images/logo.png')); ?>" rel="shortcut icon"/>
    <link href="<?php echo e(asset('images/logo.png')); ?>" rel="apple-touch-icon-precomposed"/>
    <!-- Font -->
    <link href="<?php echo e(asset('fonts/fonts.css')); ?>" rel="stylesheet"/>
    <!-- Icons -->
    <link href="<?php echo e(asset('fonts/icons-alipay.css')); ?>" rel="stylesheet"/>
    <link href="<?php echo e(asset('styles/bootstrap.css')); ?>" rel="stylesheet"/>
    <link href="<?php echo e(asset('styles/swiper-bundle.min.css')); ?>" rel="stylesheet"/>
    <link href="<?php echo e(asset('styles/styles.css')); ?>" rel="stylesheet" type="text/css">
    <link data-pwa-version="set_in_manifest_and_pwa_js" href="<?php echo e(asset('_manifest.json')); ?>" rel="manifest"/>
    <link href="<?php echo e(asset('app/icons/icon-192x192.png')); ?>" rel="apple-touch-icon" sizes="192x192"/>
    <style>
        /* Style the dropdown container */
        .dropdown {
            position: relative;
            display: inline-block;
        }

        /* Style the button (set to blue) */
        .dropdown button {
            background-color: #007BFF; /* Blue button */
            color: white;
            padding: 10px 16px;
            font-size: 16px;
            border: none;
            cursor: pointer;
            border-radius: 4px; /* Optional: for rounded corners */
        }

        /* Dropdown container: hide the items by default */
        .dropdown ul {
            display: none;
            position: absolute;
            list-style-type: none;
            margin: 0;
            padding: 0;
            background-color: #f1f1f1;
            min-width: 160px;
            box-shadow: 0px 8px 16px rgba(0, 0, 0, 0.2);
            z-index: 1;
        }

        /* Style the list items (links) in the dropdown */
        .dropdown ul li {
            padding: 12px 16px;
        }

        .dropdown ul li a {
            color: black;
            text-decoration: none;
            display: block;
        }

        /* Change color when hovering over a list item */
        .dropdown ul li a:hover {
            background-color: #ddd;
        }

        /* Show the dropdown items when the user hovers over the dropdown */
        .dropdown:hover ul {
            display: block;
        }

        /* Change button color when hovered (darker blue) */
        .dropdown:hover button {
            background-color: #0056b3; /* Darker blue */
        }
    </style>
</head>
<body>
    <!-- Preload -->
    <div class="preload preload-container" aria-busy="true" aria-live="polite">
        <div class="preload-logo">
            <div class="spinner" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
    </div>
    <!-- /Preload -->
    <div class="dropdown">
        <button>Select Language</button>
        <ul>
            <li><a href="<?php echo e(url()->current()); ?>?lang=id">Bahasa Indonesia</a></li>
            <li><a href="<?php echo e(url()->current()); ?>?lang=en">English</a></li>
            <li><a href="<?php echo e(url()->current()); ?>?lang=ru">Русский</a></li>
        </ul>
    </div>

    <?php echo $__env->yieldContent('content'); ?>

    <script type="text/javascript" src="<?php echo e(asset('javascript/jquery.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('javascript/bootstrap.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('javascript/password-addon.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('javascript/main.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('javascript/init.js')); ?>"></script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH /Users/awaludinr/Projects/zipayrussia/resources/views/layouts/app.blade.php ENDPATH**/ ?>