<?php $__env->startSection('title', 'Password Confirmed'); ?>

<?php $__env->startSection('content'); ?>
    <div class="mt-8 pw-confirm-section">
        <div class="tf-container">
            <div class="image-box">
                <img src="<?php echo e(asset('images/user/new-pass.jpg')); ?>" alt="images">
            </div>
            <div class="tf-content mt-2">
                <h1 class="mb-2 text-center">New Password Confirmed Successfully</h1>
                <p class="text-center fw_4">
                    You have successfully confirmed your new password. Please use your new password when logging in.
                </p>
            </div>
            <a href="<?php echo e(route('login')); ?>" class="tf-btn accent large">Login</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/awaludinr/Projects/zipayrussia/resources/views/password-confirm.blade.php ENDPATH**/ ?>