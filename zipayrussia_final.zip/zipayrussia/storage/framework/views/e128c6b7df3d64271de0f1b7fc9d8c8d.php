<?php $__env->startSection('title', 'Reset Password'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Preload -->
    <div class="preload preload-container">
        <div class="preload-logo">
            <div class="spinner"></div>
        </div>
    </div>
    <!-- /Preload -->

    <!-- Header -->
    <div class="header is-fixed">
        <div class="tf-container">
            <div class="tf-statusbar br-none d-flex justify-content-center align-items-center">
                <a href="#" class="back-btn"> <i class="icon-left"></i> </a>
            </div>
        </div>
    </div>

    <!-- Reset Password Section -->
    <div id="app-wrap">
        <div class="reset-pass-section mt-5">
            <div class="tf-container">
                <div class="tf-title">
                    <h1>Reset Password</h1>
                    <p>Enter your registered email below to receive password reset instructions</p>
                </div>
                <div class="image-box">
                    <img src="<?php echo e(asset('images/user/forgotpass.jpg')); ?>" alt="image">
                </div>
                <form method="POST" action="<?php echo e(route('password.reset')); ?>" class="tf-form">
                    <?php echo csrf_field(); ?>
                    <div class="group-input">
                        <label for="phoneNo">Email/Phone Number</label>
                        <input type="text" id="phoneNo" name="phoneNo" placeholder="Your Email/Phone Number" value="<?php echo e(old('phoneNo')); ?>">
                        <?php $__errorArgs = ['phoneNo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <button type="submit" class="tf-btn accent large">Next</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/awaludinr/Projects/zipayrussia/resources/views/reset-password.blade.php ENDPATH**/ ?>