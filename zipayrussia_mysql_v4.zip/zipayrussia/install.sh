#!/bin/bash
# ============================================================
# install.sh — Zipay Russia Installer (Apache2 + MySQL 8.4)
# Tested: Ubuntu 22.04 / 24.04 LTS & Debian 11/12/13
# Web Server : Apache2 + mod_php
# Database   : MySQL 8.4 Community Server
# PHP        : 8.4 (fallback 8.3)
# ============================================================
set -e

# =================== KONFIGURASI ====================
APP_DIR="/var/www/zipayrussia"
DB_NAME="zipay_db"
DB_USER="zipay_user"
DB_PASS="ZipayStr0ng2025!"    # <<< GANTI PASSWORD INI
APP_URL="http://localhost"     # <<< GANTI DENGAN IP/DOMAIN VPS
API_BASE_URL="https://apidev.zipay.id"
MID="SIDINARSBP"
MERCHANT_TOKEN="7SERR3d79Q3qzghi4YCA04qQwKn/y3gbe2ZKBmwk/1s="
# ====================================================

# Warna output
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; CYAN='\033[0;36m'; NC='\033[0m'

info()    { echo -e "${CYAN}[INFO]${NC} $1"; }
success() { echo -e "${GREEN}[OK]${NC} $1"; }
warn()    { echo -e "${YELLOW}[WARN]${NC} $1"; }
error()   { echo -e "${RED}[ERROR]${NC} $1"; exit 1; }

# Pastikan dijalankan sebagai root
[[ $EUID -ne 0 ]] && error "Jalankan script ini sebagai root: sudo bash install.sh"

export DEBIAN_FRONTEND=noninteractive
export PATH=$PATH:/usr/sbin:/usr/local/sbin

echo -e "${BLUE}"
echo "╔══════════════════════════════════════════════════════╗"
echo "║         ZIPAY RUSSIA — AUTO INSTALLER v4.0          ║"
echo "║         Apache2 + MySQL 8.4 + PHP 8.4               ║"
echo "╚══════════════════════════════════════════════════════╝"
echo -e "${NC}"

# ─── 1. DETEKSI OS ────────────────────────────────────────
info "Mendeteksi OS..."
OS_ID=$(grep -oP '(?<=^ID=).+' /etc/os-release | tr -d '"' | tr '[:upper:]' '[:lower:]')
OS_CODENAME=$(grep -oP '(?<=^VERSION_CODENAME=).+' /etc/os-release 2>/dev/null | tr -d '"')
OS_VERSION=$(grep -oP '(?<=^VERSION_ID=).+' /etc/os-release | tr -d '"')
success "OS: $OS_ID $OS_VERSION ($OS_CODENAME)"

# ─── 2. UPDATE SISTEM ─────────────────────────────────────
info "Update paket sistem..."
apt-get update -qq 2>/dev/null || warn "Update sebagian gagal, lanjut..."
apt-get upgrade -y -qq 2>/dev/null || true
apt-get install -y -qq curl wget gnupg2 ca-certificates lsb-release \
    apt-transport-https software-properties-common unzip git \
    libssl-dev libxml2-dev libcurl4-openssl-dev 2>/dev/null
success "Paket dasar terinstall"

# ─── 3. INSTALL PHP 8.4 ───────────────────────────────────
info "Setup repository PHP..."
PHP_VER=""

if [[ "$OS_ID" == "ubuntu" ]]; then
    add-apt-repository -y ppa:ondrej/php 2>/dev/null || true
    apt-get update -qq 2>/dev/null || true
    if apt-cache show php8.4 >/dev/null 2>&1; then
        PHP_VER="8.4"
    elif apt-cache show php8.3 >/dev/null 2>&1; then
        PHP_VER="8.3"
    fi
else
    # Debian
    curl -fsSL https://packages.sury.org/php/apt.gpg \
        -o /usr/share/keyrings/sury-php.gpg 2>/dev/null || \
    wget -qO /usr/share/keyrings/sury-php.gpg \
        https://packages.sury.org/php/apt.gpg 2>/dev/null || true
    echo "deb [signed-by=/usr/share/keyrings/sury-php.gpg] \
https://packages.sury.org/php/ $(lsb_release -sc) main" \
        > /etc/apt/sources.list.d/sury-php.list
    apt-get update -qq 2>/dev/null || true
    if apt-cache show php8.4 >/dev/null 2>&1; then
        PHP_VER="8.4"
    elif apt-cache show php8.3 >/dev/null 2>&1; then
        PHP_VER="8.3"
    fi
fi

[[ -z "$PHP_VER" ]] && error "Tidak dapat menemukan PHP 8.3 atau 8.4 di repositori"
info "Menginstall PHP $PHP_VER + Apache2..."

apt-get install -y -qq \
    apache2 \
    "php${PHP_VER}" \
    "libapache2-mod-php${PHP_VER}" \
    "php${PHP_VER}-cli" \
    "php${PHP_VER}-common" \
    "php${PHP_VER}-mysql" \
    "php${PHP_VER}-pdo" \
    "php${PHP_VER}-mbstring" \
    "php${PHP_VER}-xml" \
    "php${PHP_VER}-curl" \
    "php${PHP_VER}-zip" \
    "php${PHP_VER}-gd" \
    "php${PHP_VER}-bcmath" \
    "php${PHP_VER}-intl" \
    "php${PHP_VER}-tokenizer" \
    "php${PHP_VER}-fileinfo" \
    "php${PHP_VER}-dom" 2>/dev/null

PHP_BIN="php${PHP_VER}"
PHP_ACTUAL=$($PHP_BIN -v 2>/dev/null | head -1 | grep -oP '\d+\.\d+\.\d+' | head -1)
success "PHP $PHP_ACTUAL terinstall ($PHP_BIN)"

# ─── 4. KONFIGURASI APACHE ────────────────────────────────
info "Mengaktifkan modul Apache..."
a2enmod rewrite headers deflate php${PHP_VER} 2>/dev/null || true
a2dismod -f mpm_event 2>/dev/null || true
a2enmod mpm_prefork 2>/dev/null || true
success "Modul Apache aktif"

# ─── 5. INSTALL MySQL 8.4 ─────────────────────────────────
info "Memeriksa MySQL yang sudah ada..."
if command -v mysqld >/dev/null 2>&1 || command -v mysqld_safe >/dev/null 2>&1; then
    MYSQL_VER=$(mysqld --version 2>/dev/null | grep -oP '\d+\.\d+\.\d+' | head -1 || echo "unknown")
    success "MySQL $MYSQL_VER sudah terinstall, skip instalasi"
    SKIP_MYSQL_INSTALL=true
else
    SKIP_MYSQL_INSTALL=false
fi

if [[ "$SKIP_MYSQL_INSTALL" == "false" ]]; then
    info "Menambahkan MySQL 8.4 LTS repository..."

    # Deteksi base codename untuk MySQL repo
    case "$OS_ID" in
        ubuntu)
            case "$OS_VERSION" in
                22.04) MYSQL_DIST="jammy" ;;
                24.04) MYSQL_DIST="noble" ;;
                *)     MYSQL_DIST="noble" ;;
            esac
            ;;
        debian)
            case "$OS_CODENAME" in
                bullseye|bookworm) MYSQL_DIST="bookworm" ;;
                trixie|*) MYSQL_DIST="bookworm" ;;
            esac
            ;;
        *)
            MYSQL_DIST="bookworm"
            ;;
    esac

    # Import GPG key MySQL (gunakan trusted=yes sebagai fallback)
    wget -qO /tmp/mysql_pubkey.asc \
        "https://repo.mysql.com/RPM-GPG-KEY-mysql-2023" 2>/dev/null || true
    if [[ -s /tmp/mysql_pubkey.asc ]]; then
        gpg --dearmor < /tmp/mysql_pubkey.asc \
            > /usr/share/keyrings/mysql-archive-keyring.gpg 2>/dev/null || true
        MYSQL_REPO="deb [signed-by=/usr/share/keyrings/mysql-archive-keyring.gpg] \
https://repo.mysql.com/apt/debian/ ${MYSQL_DIST} mysql-8.4-lts"
    else
        warn "GPG key tidak tersedia, menggunakan trusted=yes"
        MYSQL_REPO="deb [trusted=yes] https://repo.mysql.com/apt/debian/ ${MYSQL_DIST} mysql-8.4-lts"
    fi

    echo "$MYSQL_REPO" > /etc/apt/sources.list.d/mysql-8.4.list
    apt-get update -qq 2>/dev/null || warn "Update repo MySQL sebagian gagal"

    # Tangani dependensi libaio1 di Debian 13 / Ubuntu 24.04
    if ! dpkg -l libaio1 >/dev/null 2>&1; then
        info "Menangani dependensi libaio1..."
        if apt-get install -y -qq libaio1 2>/dev/null; then
            success "libaio1 terinstall"
        elif apt-get install -y -qq libaio1t64 2>/dev/null; then
            # Buat symlink jika diperlukan
            LIB_PATH="/usr/lib/x86_64-linux-gnu"
            if [[ -f "${LIB_PATH}/libaio.so.1t64" ]] && \
               [[ ! -f "${LIB_PATH}/libaio.so.1" ]]; then
                ln -sf "${LIB_PATH}/libaio.so.1t64" "${LIB_PATH}/libaio.so.1"
                success "Symlink libaio.so.1 dibuat"
            fi
            # Buat fake package untuk satisfy dependency
            if ! dpkg -l equivs >/dev/null 2>&1; then
                apt-get install -y -qq equivs 2>/dev/null || true
            fi
            if command -v equivs-build >/dev/null 2>&1; then
                mkdir -p /tmp/equivs_libaio && cd /tmp/equivs_libaio
                cat > libaio1-compat.control << 'EOF'
Section: libs
Priority: optional
Standards-Version: 3.9.2
Package: libaio1
Version: 0.3.113
Maintainer: compat
Architecture: amd64
Description: Fake libaio1 for MySQL compatibility
EOF
                equivs-build libaio1-compat.control 2>/dev/null || true
                FAKE_DEB=$(ls libaio1_*.deb 2>/dev/null | head -1)
                [[ -n "$FAKE_DEB" ]] && dpkg -i "$FAKE_DEB" 2>/dev/null || true
                cd /
            fi
        fi
    fi

    # Install MySQL 8.4
    info "Menginstall MySQL 8.4 Community Server..."
    apt-get install -y -qq mysql-community-server 2>/dev/null || \
    apt-get install -y mysql-community-server 2>/dev/null || \
    error "Gagal menginstall MySQL. Periksa koneksi internet dan repositori."

    success "MySQL 8.4 terinstall"
fi

# ─── 6. START & KONFIGURASI MySQL ─────────────────────────
info "Memulai MySQL service..."
systemctl enable mysql 2>/dev/null || true
systemctl start mysql 2>/dev/null || \
    service mysql start 2>/dev/null || \
    mysqld_safe --daemonize 2>/dev/null || true

# Tunggu MySQL siap
MAX_WAIT=30; WAITED=0
while ! mysqladmin ping -u root --silent 2>/dev/null && [[ $WAITED -lt $MAX_WAIT ]]; do
    sleep 1; WAITED=$((WAITED+1))
done
[[ $WAITED -ge $MAX_WAIT ]] && error "MySQL tidak mau start dalam ${MAX_WAIT} detik"

# Deteksi MySQL socket
MYSQL_SOCKET=""
for SOCK in /var/run/mysqld/mysqld.sock /run/mysqld/mysqld.sock \
            /tmp/mysql.sock /var/lib/mysql/mysql.sock; do
    if [[ -S "$SOCK" ]]; then
        MYSQL_SOCKET="$SOCK"
        break
    fi
done
success "MySQL berjalan (socket: ${MYSQL_SOCKET:-TCP})"

# ─── 7. BUAT DATABASE & USER ──────────────────────────────
info "Membuat database dan user MySQL..."
MYSQL_CMD="mysql -u root"
[[ -n "$MYSQL_SOCKET" ]] && MYSQL_CMD="mysql --socket=$MYSQL_SOCKET -u root"

$MYSQL_CMD 2>/dev/null << MYSQL_EOF
CREATE DATABASE IF NOT EXISTS \`${DB_NAME}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER IF NOT EXISTS '${DB_USER}'@'localhost' IDENTIFIED BY '${DB_PASS}';
CREATE USER IF NOT EXISTS '${DB_USER}'@'127.0.0.1' IDENTIFIED BY '${DB_PASS}';
GRANT ALL PRIVILEGES ON \`${DB_NAME}\`.* TO '${DB_USER}'@'localhost';
GRANT ALL PRIVILEGES ON \`${DB_NAME}\`.* TO '${DB_USER}'@'127.0.0.1';
FLUSH PRIVILEGES;
MYSQL_EOF

success "Database '${DB_NAME}' dan user '${DB_USER}' dibuat"

# ─── 8. IMPORT SKEMA DATABASE ─────────────────────────────
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SQL_FILE=""
for TRY in "$SCRIPT_DIR/zipay_database.sql" \
           "$(dirname "$SCRIPT_DIR")/zipay_database.sql" \
           "/tmp/zipay_database.sql"; do
    [[ -f "$TRY" ]] && SQL_FILE="$TRY" && break
done

if [[ -n "$SQL_FILE" ]]; then
    info "Import skema dari $SQL_FILE..."
    $MYSQL_CMD "$DB_NAME" < "$SQL_FILE" 2>/dev/null
    success "Skema database diimport"
else
    warn "File zipay_database.sql tidak ditemukan, skip import (akan dijalankan migrate)"
fi

# ─── 9. INSTALL COMPOSER ──────────────────────────────────
if ! command -v composer >/dev/null 2>&1; then
    info "Menginstall Composer..."
    EXPECTED_CHECKSUM="$(wget -q -O - https://composer.github.io/installer.sig 2>/dev/null)"
    $PHP_BIN -r "copy('https://getcomposer.org/installer', '/tmp/composer-setup.php');"
    if [[ -n "$EXPECTED_CHECKSUM" ]]; then
        ACTUAL_CHECKSUM="$($PHP_BIN -r "echo hash_file('sha384', '/tmp/composer-setup.php');")"
        [[ "$EXPECTED_CHECKSUM" != "$ACTUAL_CHECKSUM" ]] && \
            error "Composer installer checksum tidak valid!"
    fi
    $PHP_BIN /tmp/composer-setup.php --install-dir=/usr/local/bin \
        --filename=composer --quiet 2>/dev/null
    rm -f /tmp/composer-setup.php
    success "Composer $(composer --version 2>/dev/null | grep -oP '\d+\.\d+\.\d+' | head -1) terinstall"
else
    success "Composer sudah ada: $(composer --version 2>/dev/null | head -1)"
fi

# ─── 10. DEPLOY SOURCE CODE ───────────────────────────────
info "Deploy source code ke $APP_DIR..."
mkdir -p "$APP_DIR"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Salin source (tanpa install.sh, *.sql, *.zip, *.conf, .git)
rsync -a --exclude='install*.sh' --exclude='*.sql' --exclude='*.zip' \
    --exclude='*.conf' --exclude='.git' --exclude='vendor' \
    --exclude='node_modules' --exclude='.env' \
    "$SCRIPT_DIR/" "$APP_DIR/" 2>/dev/null || \
    cp -r "$SCRIPT_DIR/." "$APP_DIR/" 2>/dev/null || true

# Pastikan artisan dan composer.json ada
if [[ ! -f "$APP_DIR/artisan" ]]; then
    warn "File artisan tidak ditemukan di $APP_DIR. Pastikan source code ada."
fi

chown -R www-data:www-data "$APP_DIR"
chmod -R 755 "$APP_DIR"
success "Source code di-deploy ke $APP_DIR"

# ─── 11. COMPOSER INSTALL ─────────────────────────────────
if [[ -f "$APP_DIR/composer.json" ]]; then
    info "Menjalankan Composer install..."
    cd "$APP_DIR"
    sudo -u www-data composer install \
        --no-dev --optimize-autoloader --no-interaction --quiet 2>/dev/null || \
    sudo -u www-data composer install \
        --no-interaction --quiet 2>/dev/null || \
    warn "Composer install ada masalah, lanjut..."
    success "Composer install selesai"
fi

# ─── 12. BUAT FILE .env ───────────────────────────────────
info "Membuat file .env..."
SERVER_NAME=$(echo "$APP_URL" | sed 's|https\?://||' | cut -d'/' -f1)
APP_KEY_VAL=""  # Akan di-generate setelah .env dibuat

cat > "$APP_DIR/.env" << ENV
APP_NAME="Zipay Russia"
APP_ENV=production
APP_KEY=
APP_DEBUG=false
APP_TIMEZONE=Asia/Jakarta
APP_URL=${APP_URL}

LOG_CHANNEL=stack
LOG_DEPRECATIONS_CHANNEL=null
LOG_LEVEL=error

DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=${DB_NAME}
DB_USERNAME=${DB_USER}
DB_PASSWORD=${DB_PASS}
DB_SOCKET=${MYSQL_SOCKET}
DB_CHARSET=utf8mb4
DB_COLLATION=utf8mb4_unicode_ci

BROADCAST_CONNECTION=log
FILESYSTEM_DISK=local
QUEUE_CONNECTION=sync
SESSION_DRIVER=file
SESSION_LIFETIME=120
SESSION_ENCRYPT=false
SESSION_PATH=/
SESSION_DOMAIN=null

CACHE_STORE=file
CACHE_PREFIX=

MAIL_MAILER=log
MAIL_HOST=127.0.0.1
MAIL_PORT=2525
MAIL_USERNAME=null
MAIL_PASSWORD=null
MAIL_ENCRYPTION=null
MAIL_FROM_ADDRESS="hello@zipay.id"
MAIL_FROM_NAME="Zipay Russia"

API_BASE_URL=${API_BASE_URL}
MID=${MID}
MERCHANT_TOKEN=${MERCHANT_TOKEN}
ENV

chown www-data:www-data "$APP_DIR/.env"
chmod 640 "$APP_DIR/.env"
success ".env dibuat"

# ─── 13. GENERATE APP KEY ─────────────────────────────────
info "Generate Laravel APP_KEY..."
cd "$APP_DIR"
APP_KEY_VAL=$(sudo -u www-data $PHP_BIN artisan key:generate --show --force 2>/dev/null | \
              grep -oP 'base64:[A-Za-z0-9+/=]+' | head -1)
if [[ -z "$APP_KEY_VAL" ]]; then
    APP_KEY_VAL="base64:$(openssl rand -base64 32)"
fi
sed -i "s|^APP_KEY=.*|APP_KEY=${APP_KEY_VAL}|" "$APP_DIR/.env"
success "APP_KEY di-generate"

# ─── 14. SET PERMISSIONS ──────────────────────────────────
info "Set permissions..."
chown -R www-data:www-data "$APP_DIR"
find "$APP_DIR" -type f -exec chmod 644 {} \;
find "$APP_DIR" -type d -exec chmod 755 {} \;
chmod -R 775 "$APP_DIR/storage" "$APP_DIR/bootstrap/cache"
chmod 640 "$APP_DIR/.env"
chmod +x "$APP_DIR/artisan"
success "Permissions diset"

# ─── 15. STORAGE LINK ─────────────────────────────────────
info "Membuat storage link..."
rm -f "$APP_DIR/public/storage"
if sudo -u www-data $PHP_BIN "$APP_DIR/artisan" storage:link 2>/dev/null; then
    success "Storage link via artisan"
elif ln -sf "$APP_DIR/storage/app/public" "$APP_DIR/public/storage" 2>/dev/null; then
    success "Storage link manual dibuat"
else
    warn "Storage link gagal, buat manual jika diperlukan"
fi

# ─── 16. MIGRATE DATABASE ─────────────────────────────────
info "Menjalankan migrasi database..."
cd "$APP_DIR"
TABLE_COUNT=$(mysql --socket="$MYSQL_SOCKET" -u "$DB_USER" -p"$DB_PASS" \
    -e "SELECT COUNT(*) FROM information_schema.tables \
    WHERE table_schema='${DB_NAME}';" 2>/dev/null | tail -1 || echo "0")

if [[ "$TABLE_COUNT" -ge 9 ]]; then
    success "Database sudah memiliki $TABLE_COUNT tabel, skip migrate"
else
    sudo -u www-data $PHP_BIN artisan migrate --force 2>/dev/null || \
        warn "Migrate ada masalah, periksa log"
    success "Migrate selesai"
fi

# ─── 17. CACHE PRODUCTION ─────────────────────────────────
info "Build production cache..."
cd "$APP_DIR"
sudo -u www-data $PHP_BIN artisan config:cache 2>/dev/null && \
    success "Config cached"
sudo -u www-data $PHP_BIN artisan route:cache 2>/dev/null && \
    success "Routes cached"
sudo -u www-data $PHP_BIN artisan view:cache 2>/dev/null && \
    success "Views cached"

# ─── 18. BUAT VIRTUALHOST APACHE ──────────────────────────
info "Membuat VirtualHost Apache..."
cat > /etc/apache2/sites-available/zipayrussia.conf << VHOST
<VirtualHost *:80>
    ServerName ${SERVER_NAME}
    ServerAlias *
    DocumentRoot ${APP_DIR}/public

    <Directory ${APP_DIR}/public>
        Options -Indexes +FollowSymLinks +MultiViews
        AllowOverride All
        Require all granted
    </Directory>

    # Security Headers
    Header always set X-Frame-Options "SAMEORIGIN"
    Header always set X-Content-Type-Options "nosniff"
    Header always set X-XSS-Protection "1; mode=block"
    Header always set Referrer-Policy "no-referrer-when-downgrade"

    # Compression
    <IfModule mod_deflate.c>
        AddOutputFilterByType DEFLATE text/plain text/css
        AddOutputFilterByType DEFLATE application/json application/javascript
        AddOutputFilterByType DEFLATE text/html text/xml
    </IfModule>

    # PHP Limits
    <IfModule mod_php${PHP_VER}.c>
        php_value upload_max_filesize 20M
        php_value post_max_size 20M
        php_value max_execution_time 60
        php_value memory_limit 256M
    </IfModule>

    ErrorLog  \${APACHE_LOG_DIR}/zipayrussia_error.log
    CustomLog \${APACHE_LOG_DIR}/zipayrussia_access.log combined
</VirtualHost>
VHOST

# Set ServerTokens di apache2.conf (bukan di VirtualHost)
if ! grep -q "^ServerTokens Prod" /etc/apache2/apache2.conf 2>/dev/null; then
    echo "ServerTokens Prod" >> /etc/apache2/apache2.conf
fi
if ! grep -q "^ServerSignature Off" /etc/apache2/apache2.conf 2>/dev/null; then
    echo "ServerSignature Off" >> /etc/apache2/apache2.conf
fi

# Enable site, disable default
a2ensite zipayrussia 2>/dev/null || true
a2dissite 000-default default-ssl 2>/dev/null || true

# Test konfigurasi Apache
if /usr/sbin/apache2ctl configtest 2>&1 | grep -q "Syntax OK"; then
    success "Apache config syntax OK"
else
    /usr/sbin/apache2ctl configtest
    error "Konfigurasi Apache bermasalah!"
fi

# ─── 19. START/RESTART SERVICES ───────────────────────────
info "Restart services..."
systemctl enable apache2 mysql 2>/dev/null || true
systemctl restart apache2 2>/dev/null || service apache2 restart 2>/dev/null
systemctl restart mysql 2>/dev/null || service mysql restart 2>/dev/null
success "Apache dan MySQL aktif"

# ─── 20. VERIFIKASI INSTALASI ─────────────────────────────
info "Verifikasi instalasi..."
sleep 2

HTTP_STATUS=$(curl -s -o /dev/null -w "%{http_code}" "http://localhost/" 2>/dev/null || echo "000")
HEALTH_STATUS=$(curl -s -o /dev/null -w "%{http_code}" "http://localhost/up" 2>/dev/null || echo "000")

if [[ "$HTTP_STATUS" == "200" ]] || [[ "$HTTP_STATUS" == "302" ]]; then
    success "✅ HTTP test: / → ${HTTP_STATUS}"
else
    warn "HTTP test: / → ${HTTP_STATUS} (mungkin perlu beberapa detik)"
fi

if [[ "$HEALTH_STATUS" == "200" ]]; then
    success "✅ Health check: /up → 200 OK"
else
    warn "Health check: /up → ${HEALTH_STATUS}"
fi

# ─── SELESAI ──────────────────────────────────────────────
PHP_FINAL=$($PHP_BIN -v 2>/dev/null | head -1 | grep -oP '\d+\.\d+\.\d+' | head -1)
MYSQL_FINAL=$(mysqld --version 2>/dev/null | grep -oP '\d+\.\d+\.\d+' | head -1 || echo "N/A")
APACHE_FINAL=$(/usr/sbin/apache2 -v 2>/dev/null | grep 'Server version' | grep -oP '\d+\.\d+\.\d+' | head -1 || echo "N/A")

echo ""
echo -e "${GREEN}"
echo "╔══════════════════════════════════════════════════════╗"
echo "║           ✅ INSTALASI BERHASIL!                     ║"
echo "╚══════════════════════════════════════════════════════╝"
echo -e "${NC}"
echo -e "  🌐 URL Aplikasi : ${CYAN}${APP_URL}${NC}"
echo -e "  📁 App Directory: ${APP_DIR}"
echo -e "  🗄️  Database     : ${DB_NAME} (user: ${DB_USER})"
echo -e "  🔌 MySQL Socket  : ${MYSQL_SOCKET:-127.0.0.1:3306}"
echo -e "  🐘 PHP Version   : ${PHP_FINAL}"
echo -e "  🐬 MySQL Version : ${MYSQL_FINAL}"
echo -e "  🌍 Apache Version: ${APACHE_FINAL}"
echo ""
echo -e "  📋 Health Check  : curl http://localhost/up"
echo -e "  📋 Login Page    : ${APP_URL}/login"
echo ""
echo -e "  📄 Error Log Apache : /var/log/apache2/zipayrussia_error.log"
echo -e "  📄 Laravel Log      : ${APP_DIR}/storage/logs/laravel.log"
echo ""
