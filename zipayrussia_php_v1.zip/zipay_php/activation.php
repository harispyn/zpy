<?php
// ============================================================
//  activation.php – Aktivasi akun via API
// ============================================================
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/session.php';
require_once __DIR__ . '/includes/api.php';

$errors  = [];
$success = session_flash_get('success');
$phoneNo = trim($_GET['phoneNo'] ?? $_POST['phoneNo'] ?? '');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify()) {
        $errors[] = 'Token keamanan tidak valid.';
    } else {
        $phoneNo = trim($_POST['phoneNo'] ?? '');
        if ($phoneNo === '') {
            $errors[] = 'Nomor telepon wajib diisi.';
        } else {
            $result = api_post('/api/Multipocket/Activation', base_payload([
                'phoneNo'  => $phoneNo,
                'deviceID' => base64_encode($phoneNo), // simple device ID
            ]));

            if ($result['ok']) {
                session_flash('success', 'Aktivasi berhasil! Silakan verifikasi OTP.');
                header('Location: /verify-otp?phoneNo=' . urlencode($phoneNo));
                exit;
            } else {
                $errors[] = 'Aktivasi gagal: ' . $result['message'];
            }
        }
    }
}

$page_title = 'Aktivasi Akun';
$show_back  = true;
require __DIR__ . '/includes/layout_header.php';
?>

<div class="mt-3 activation-section">
    <div class="tf-container">
        <form class="tf-form" action="/activation" method="POST">
            <?= csrf_field() ?>
            <h1>Aktivasi Akun</h1>
            <p class="fw_4">Masukkan nomor telepon yang terdaftar untuk mengirim kode OTP.</p>

            <?php if ($success): ?>
                <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
            <?php endif; ?>
            <?php if ($errors): ?>
                <div class="alert alert-danger"><ul>
                    <?php foreach ($errors as $e): ?>
                        <li><?= htmlspecialchars($e) ?></li>
                    <?php endforeach; ?>
                </ul></div>
            <?php endif; ?>

            <div class="group-input">
                <label>Nomor Telepon</label>
                <input type="tel" name="phoneNo" placeholder="Contoh: 08123456789"
                       value="<?= htmlspecialchars($phoneNo) ?>" required>
            </div>

            <button type="submit" class="tf-btn accent large">Kirim OTP</button>

            <p class="mt-3 text-center">
                <a href="/login">Kembali ke Login</a>
            </p>
        </form>
    </div>
</div>

<?php require __DIR__ . '/includes/layout_footer.php'; ?>
