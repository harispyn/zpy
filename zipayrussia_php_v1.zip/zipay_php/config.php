<?php
// ============================================================
//  config.php – Konfigurasi Zipay Russia (PHP Murni)
//  Edit bagian ini sebelum deploy
// ============================================================

// ── Database MySQL ──────────────────────────────────────────
define('DB_HOST',     getenv('DB_HOST')     ?: '127.0.0.1');
define('DB_PORT',     getenv('DB_PORT')     ?: '3306');
define('DB_NAME',     getenv('DB_NAME')     ?: 'zipay_db');
define('DB_USER',     getenv('DB_USER')     ?: 'zipay_user');
define('DB_PASS',     getenv('DB_PASS')     ?: 'ZipayPass123!');

// ── Multipocket API ─────────────────────────────────────────
define('API_BASE_URL',      getenv('API_BASE_URL')      ?: 'https://apidev.zipay.id');
define('API_MID',           getenv('MID')               ?: 'SIDINARSBP');
define('API_MERCHANT_TOKEN',getenv('MERCHANT_TOKEN')    ?: '7SERR3d79Q3qzghi4YCA04qQwKn/y3gbe2ZKBmwk/1s=');

// ── Aplikasi ─────────────────────────────────────────────────
define('APP_NAME',  'Zipay Russia');
define('APP_URL',   getenv('APP_URL') ?: 'http://localhost');
define('APP_DEBUG', false);

// ── Session ──────────────────────────────────────────────────
define('SESSION_LIFETIME', 7200); // 2 jam (detik)

// ── Timezone ─────────────────────────────────────────────────
date_default_timezone_set('Asia/Jakarta');

// ── Error reporting ──────────────────────────────────────────
if (APP_DEBUG) {
    error_reporting(E_ALL);
    ini_set('display_errors', '1');
} else {
    error_reporting(0);
    ini_set('display_errors', '0');
}
