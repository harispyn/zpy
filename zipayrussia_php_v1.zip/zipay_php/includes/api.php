<?php
// ============================================================
//  includes/api.php – Helper curl untuk Multipocket API
// ============================================================
require_once __DIR__ . '/../config.php';

/**
 * Kirim POST request ke Multipocket API
 *
 * @param  string $endpoint   Misal: '/api/Multipocket/Register'
 * @param  array  $payload    Data JSON yang dikirim
 * @param  string $token      Bearer token (opsional)
 * @return array  ['ok'=>bool, 'status'=>int, 'data'=>array|null, 'message'=>string]
 */
function api_post(string $endpoint, array $payload, string $token = ''): array {
    $url     = rtrim(API_BASE_URL, '/') . $endpoint;
    $json    = json_encode($payload);
    $headers = [
        'Content-Type: application/json',
        'Accept: application/json',
        'Content-Length: ' . strlen($json),
    ];
    if ($token) {
        $headers[] = 'Authorization: Bearer ' . $token;
    }

    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL            => $url,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => $json,
        CURLOPT_HTTPHEADER     => $headers,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 30,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_FOLLOWLOCATION => false,
    ]);

    $body       = curl_exec($ch);
    $httpStatus = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlError  = curl_error($ch);
    curl_close($ch);

    // cURL error (network / timeout)
    if ($body === false || $curlError) {
        error_log("[API] cURL error on {$endpoint}: {$curlError}");
        return [
            'ok'      => false,
            'status'  => 0,
            'data'    => null,
            'message' => 'Tidak dapat terhubung ke server API. Periksa koneksi VPS.',
        ];
    }

    // Parse JSON body
    $decoded = json_decode($body, true);

    // HTTP 2xx = sukses
    if ($httpStatus >= 200 && $httpStatus < 300) {
        return [
            'ok'      => true,
            'status'  => $httpStatus,
            'data'    => $decoded,
            'message' => $decoded['message'] ?? $decoded['Message'] ?? 'Sukses',
        ];
    }

    // HTTP error — ekstrak pesan
    $message = null;
    if (is_array($decoded)) {
        $message = $decoded['message'] ?? $decoded['Message'] ?? $decoded['error'] ?? $decoded['Error'] ?? null;
    }
    if (!$message) {
        $message = api_status_message($httpStatus);
    }

    error_log("[API] HTTP {$httpStatus} on {$endpoint}: {$message}");
    return [
        'ok'      => false,
        'status'  => $httpStatus,
        'data'    => $decoded,
        'message' => $message,
    ];
}

function api_status_message(int $code): string {
    return match($code) {
        400 => 'Data tidak valid atau format permintaan salah.',
        401 => 'Autentikasi gagal. Periksa MID/Merchant Token.',
        403 => 'Akses ditolak oleh server API.',
        404 => 'Endpoint API tidak ditemukan.',
        422 => 'Data tidak dapat diproses.',
        429 => 'Terlalu banyak percobaan. Coba lagi nanti.',
        500 => 'Kesalahan internal server API.',
        502 => 'API Gateway error (Bad Gateway).',
        503 => 'Server API tidak tersedia sementara.',
        504 => 'Server API timeout.',
        default => "Server merespon HTTP {$code}.",
    };
}

/** Buat payload dasar dengan mid + merchantToken */
function base_payload(array $extra = []): array {
    return array_merge([
        'mid'           => API_MID,
        'merchantToken' => API_MERCHANT_TOKEN,
    ], $extra);
}
