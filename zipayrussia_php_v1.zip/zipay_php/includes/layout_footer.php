<?php
// layout_footer.php – Penutup HTML
?>
<script src="/javascript/jquery.min.js"></script>
<script src="/javascript/bootstrap.min.js"></script>
<script src="/javascript/password-addon.js"></script>
<script src="/javascript/main.js"></script>
<script src="/javascript/init.js"></script>
<?php if (!empty($extra_scripts)) echo $extra_scripts; ?>
<script>
    // Sembunyikan preload setelah load
    window.addEventListener('load', function() {
        var el = document.getElementById('preload');
        if (el) { el.style.display = 'none'; }
    });
    // Simpan lang ke localStorage
    (function(){
        var p = new URLSearchParams(window.location.search);
        if (p.get('lang')) localStorage.setItem('lang', p.get('lang'));
    })();
</script>
</body>
</html>
