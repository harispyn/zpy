#!/usr/bin/env bash
# =============================================================================
#  install_apache_mysql.sh – Installer Zipay Russia (PHP Murni + Apache2 + MySQL)
#  Target : Ubuntu 22.04 / 24.04 atau Debian 11/12
#  Jalankan: sudo bash install_apache_mysql.sh
# =============================================================================
set -euo pipefail

# ──────────────────────────────────────────────
#  KONFIGURASI – WAJIB EDIT SEBELUM DIJALANKAN
# ──────────────────────────────────────────────
APP_DIR="/var/www/zipayrussia"
DB_NAME="zipay_db"
DB_USER="zipay_user"
DB_PASS="ZipayPass_$(openssl rand -hex 6)"   # akan di-override jika set manual
APP_URL="http://$(hostname -I | awk '{print $1}')"

# Multipocket API
API_BASE_URL="https://apidev.zipay.id"
MID="SIDINARSBP"
MERCHANT_TOKEN="7SERR3d79Q3qzghi4YCA04qQwKn/y3gbe2ZKBmwk/1s="

# PHP version target
PHP_VER="8.4"   # atau 8.2 / 8.3
# ──────────────────────────────────────────────

# Warna output
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; NC='\033[0m'
info()    { echo -e "${BLUE}[INFO]${NC}  $*"; }
success() { echo -e "${GREEN}[OK]${NC}    $*"; }
warn()    { echo -e "${YELLOW}[WARN]${NC}  $*"; }
error()   { echo -e "${RED}[ERROR]${NC} $*"; exit 1; }

check_root() {
    [[ $EUID -ne 0 ]] && error "Jalankan sebagai root: sudo bash $0"
}

detect_os() {
    if [[ -f /etc/os-release ]]; then
        . /etc/os-release
        OS_ID="$ID"
        OS_VER="$VERSION_ID"
    else
        error "Tidak dapat mendeteksi OS."
    fi
    info "OS: $OS_ID $OS_VER"
}

# ── 1. Update sistem ──────────────────────────
install_base() {
    info "Update apt dan install paket dasar..."
    apt-get update -qq
    apt-get install -y -qq \
        curl wget gnupg2 lsb-release ca-certificates \
        unzip zip software-properties-common apt-transport-https \
        openssl 2>/dev/null
    success "Paket dasar terinstall"
}

# ── 2. Install PHP 8.x ───────────────────────
install_php() {
    info "Install PHP ${PHP_VER}..."

    # Tambah repo ondrej/php untuk Ubuntu, atau sury untuk Debian
    if [[ "$OS_ID" == "ubuntu" ]]; then
        add-apt-repository -y ppa:ondrej/php 2>/dev/null || true
    else
        # Debian
        curl -fsSL https://packages.sury.org/php/apt.gpg \
            | gpg --dearmor -o /usr/share/keyrings/sury-php.gpg
        echo "deb [signed-by=/usr/share/keyrings/sury-php.gpg] https://packages.sury.org/php/ $(lsb_release -cs) main" \
            > /etc/apt/sources.list.d/sury-php.list
    fi

    apt-get update -qq
    apt-get install -y -qq \
        php${PHP_VER} \
        php${PHP_VER}-cli \
        php${PHP_VER}-fpm \
        php${PHP_VER}-mysql \
        php${PHP_VER}-curl \
        php${PHP_VER}-mbstring \
        php${PHP_VER}-xml \
        php${PHP_VER}-zip \
        php${PHP_VER}-gd \
        php${PHP_VER}-intl \
        php${PHP_VER}-bcmath \
        libapache2-mod-php${PHP_VER}

    PHP_BIN=$(command -v php${PHP_VER} || command -v php)
    success "PHP $($PHP_BIN -r 'echo PHP_VERSION;') terinstall"
}

# ── 3. Install Apache2 ───────────────────────
install_apache() {
    info "Install Apache2..."
    apt-get install -y -qq apache2

    # Disable mpm_event, aktifkan mpm_prefork (kompatibel mod_php)
    a2dismod mpm_event  2>/dev/null || true
    a2enmod  mpm_prefork 2>/dev/null

    # Disable semua modul PHP lain lalu enable yang benar
    for mod in $(ls /etc/apache2/mods-enabled/php*.load 2>/dev/null | xargs -I{} basename {} .load); do
        a2dismod "$mod" 2>/dev/null || true
    done
    a2enmod  "php${PHP_VER}"
    a2enmod  rewrite
    a2enmod  headers
    a2enmod  deflate

    systemctl enable apache2
    systemctl start  apache2
    success "Apache2 terinstall dan berjalan"
}

# ── 4. Install MySQL 8 ───────────────────────
install_mysql() {
    info "Install MySQL 8..."
    apt-get install -y -qq mysql-server 2>/dev/null || true

    # Coba repo resmi MySQL 8.4 jika versi default < 8
    if ! mysql --version 2>/dev/null | grep -qE "8\.[0-9]"; then
        warn "Mencoba repo MySQL 8 resmi..."
        cd /tmp
        MYSQL_PKG="mysql-apt-config_0.8.30-1_all.deb"
        wget -q "https://dev.mysql.com/get/${MYSQL_PKG}" -O /tmp/${MYSQL_PKG}
        DEBIAN_FRONTEND=noninteractive dpkg -i /tmp/${MYSQL_PKG} || true
        apt-get update -qq
        apt-get install -y -qq mysql-server
        rm -f /tmp/${MYSQL_PKG}
    fi

    systemctl enable mysql
    systemctl start  mysql

    # Tunggu MySQL siap
    for i in $(seq 1 15); do
        mysqladmin ping --silent 2>/dev/null && break
        sleep 2
    done

    success "MySQL $(mysql --version | awk '{print $3}') terinstall"
}

# ── 5. Buat database & user ──────────────────
setup_mysql() {
    info "Membuat database '${DB_NAME}' dan user '${DB_USER}'..."

    mysql -u root <<SQL
CREATE DATABASE IF NOT EXISTS \`${DB_NAME}\`
    CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE USER IF NOT EXISTS '${DB_USER}'@'localhost' IDENTIFIED BY '${DB_PASS}';
GRANT ALL PRIVILEGES ON \`${DB_NAME}\`.* TO '${DB_USER}'@'localhost';
FLUSH PRIVILEGES;
SQL

    # Import skema jika ada
    local SQL_FILE="$(dirname "$0")/zipay_database.sql"
    if [[ -f "$SQL_FILE" ]]; then
        mysql -u root "${DB_NAME}" < "$SQL_FILE"
        success "Skema database diimport dari $SQL_FILE"
    fi

    success "Database dan user MySQL siap"
}

# ── 6. Deploy source code ────────────────────
deploy_source() {
    info "Deploy source code ke ${APP_DIR}..."

    # Buat direktori
    mkdir -p "${APP_DIR}"

    # Source ada di folder yang sama dengan script ini
    SRC_DIR="$(dirname "$(realpath "$0")")/src"
    if [[ -d "$SRC_DIR" ]]; then
        rsync -a --exclude='.git' --exclude='*.sql' \
              "${SRC_DIR}/" "${APP_DIR}/"
    else
        # Fallback: source ada di folder installer sendiri
        SRC_DIR="$(dirname "$(realpath "$0")")"
        rsync -a --exclude='.git' --exclude='*.sql' \
              --exclude='install*.sh' \
              --include='*.php' --include='*.htaccess' \
              --include='includes/***' \
              --filter='protect .git/' \
              "${SRC_DIR}/" "${APP_DIR}/" 2>/dev/null || true
    fi

    success "Source code di-deploy ke ${APP_DIR}"
}

# ── 7. Copy assets dari original public/ ─────
copy_assets() {
    info "Menyalin asset CSS/JS/Images..."
    # Jika ada folder assets dari project Laravel lama
    ASSET_SRC="$(dirname "$(realpath "$0")")/public"
    if [[ -d "$ASSET_SRC" ]]; then
        rsync -a "${ASSET_SRC}/" "${APP_DIR}/" \
              --exclude='index.php' --exclude='*.htaccess'
        success "Asset disalin dari ${ASSET_SRC}"
    else
        warn "Folder public/ tidak ditemukan, asset perlu disalin manual"
    fi
}

# ── 8. Generate config.php dengan nilai env ──
write_config() {
    info "Menulis config.php..."
    cat > "${APP_DIR}/config.php" <<PHPEOF
<?php
// Auto-generated by install script — $(date)
define('DB_HOST',              '127.0.0.1');
define('DB_PORT',              '3306');
define('DB_NAME',              '${DB_NAME}');
define('DB_USER',              '${DB_USER}');
define('DB_PASS',              '${DB_PASS}');
define('API_BASE_URL',         '${API_BASE_URL}');
define('API_MID',              '${MID}');
define('API_MERCHANT_TOKEN',   '${MERCHANT_TOKEN}');
define('APP_NAME',             'Zipay Russia');
define('APP_URL',              '${APP_URL}');
define('APP_DEBUG',            false);
define('SESSION_LIFETIME',     7200);
date_default_timezone_set('Asia/Jakarta');
error_reporting(0);
ini_set('display_errors', '0');
PHPEOF
    success "config.php ditulis"
}

# ── 9. Set permissions ───────────────────────
set_permissions() {
    info "Set permissions..."
    chown -R www-data:www-data "${APP_DIR}"
    find "${APP_DIR}" -type d -exec chmod 755 {} \;
    find "${APP_DIR}" -type f -exec chmod 644 {} \;
    chmod 640 "${APP_DIR}/config.php"
    chmod 640 "${APP_DIR}/includes/"*.php 2>/dev/null || true
    success "Permissions diset"
}

# ── 10. Konfigurasi Apache VirtualHost ───────
configure_apache() {
    info "Konfigurasi Apache VirtualHost..."

    cat > /etc/apache2/sites-available/zipayrussia.conf <<APACHEEOF
<VirtualHost *:80>
    ServerName   $(echo "$APP_URL" | sed 's|https\?://||')
    DocumentRoot ${APP_DIR}

    <Directory ${APP_DIR}>
        Options -Indexes +FollowSymLinks
        AllowOverride All
        Require all granted

        <IfModule mod_php.c>
            php_value upload_max_filesize 20M
            php_value post_max_size       20M
            php_value max_execution_time  60
            php_value memory_limit        256M
            php_flag  display_errors      Off
            php_value session.gc_maxlifetime 7200
            php_value session.cookie_httponly 1
        </IfModule>
    </Directory>

    # Blokir akses langsung ke config & includes
    <FilesMatch "(config\.php|^includes)">
        Require all denied
    </FilesMatch>

    ErrorLog  \${APACHE_LOG_DIR}/zipayrussia_error.log
    CustomLog \${APACHE_LOG_DIR}/zipayrussia_access.log combined
</VirtualHost>
APACHEEOF

    # Disable default site, enable zipayrussia
    a2dissite 000-default 2>/dev/null || true
    a2ensite  zipayrussia
    apache2ctl configtest && systemctl reload apache2
    success "VirtualHost Apache dikonfigurasi"
}

# ── 11. Smoke test ───────────────────────────
smoke_test() {
    info "Smoke test HTTP..."
    sleep 2
    for route in "/" "/login" "/register"; do
        CODE=$(curl -s -o /dev/null -w "%{http_code}" "http://localhost${route}" || echo "000")
        if [[ "$CODE" == "200" || "$CODE" == "302" ]]; then
            success "${route} → HTTP ${CODE}"
        else
            warn "${route} → HTTP ${CODE} (periksa log)"
        fi
    done
}

# ── 12. Ringkasan ─────────────────────────────
print_summary() {
    echo ""
    echo -e "${GREEN}╔══════════════════════════════════════════════════════╗${NC}"
    echo -e "${GREEN}║          INSTALASI SELESAI – Zipay Russia            ║${NC}"
    echo -e "${GREEN}╚══════════════════════════════════════════════════════╝${NC}"
    echo ""
    echo -e "  URL Aplikasi : ${YELLOW}${APP_URL}${NC}"
    echo -e "  App Dir      : ${APP_DIR}"
    echo -e "  Database     : ${DB_NAME}"
    echo -e "  DB User      : ${DB_USER}"
    echo -e "  DB Password  : ${RED}${DB_PASS}${NC}  ← SIMPAN INI!"
    echo -e "  API Base URL : ${API_BASE_URL}"
    echo -e "  MID          : ${MID}"
    echo ""
    echo -e "  Logs Apache  : /var/log/apache2/zipayrussia_error.log"
    echo ""
    echo -e "  Perintah berguna:"
    echo -e "    ${BLUE}systemctl status apache2${NC}"
    echo -e "    ${BLUE}systemctl status mysql${NC}"
    echo -e "    ${BLUE}tail -f /var/log/apache2/zipayrussia_error.log${NC}"
    echo ""
}

# ── MAIN ─────────────────────────────────────
main() {
    check_root
    detect_os
    install_base
    install_php
    install_apache
    install_mysql
    setup_mysql
    deploy_source
    copy_assets
    write_config
    set_permissions
    configure_apache
    smoke_test
    print_summary
}

main "$@"
