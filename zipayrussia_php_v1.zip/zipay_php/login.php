<?php
// ============================================================
//  login.php – Halaman & proses login
// ============================================================
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/session.php';
require_once __DIR__ . '/includes/api.php';

require_guest();

$errors  = [];
$success = session_flash_get('success');
$old     = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify()) {
        $errors[] = 'Token keamanan tidak valid. Muat ulang halaman.';
    } else {
        $username   = trim($_POST['username']   ?? '');
        $password   = $_POST['password']        ?? '';
        $deviceType = trim($_POST['deviceType'] ?? 'android');
        $deviceId   = trim($_POST['deviceId']   ?? (string)mt_rand(100000000000000, 999999999999999));

        $old = ['username' => $username, 'deviceType' => $deviceType];

        if ($username === '') $errors[] = 'Username wajib diisi.';
        if ($password === '') $errors[] = 'Password wajib diisi.';

        if (empty($errors)) {
            $result = api_post('/api/Auth/Login', [
                'username'   => $username,
                'password'   => $password,
                'deviceType' => $deviceType,
                'deviceId'   => $deviceId,
            ]);

            if ($result['ok']) {
                $data  = $result['data']['result'] ?? $result['data'] ?? [];
                $token = $data['token'] ?? ($result['data']['token'] ?? '');

                // Simpan ke session
                session_set('logged_in',    true);
                session_set('token',        $token);
                session_set('api_response', $data);
                session_set('phoneNumber',  $data['phoneNumber'] ?? '');
                session_set('firstName',    $data['firstName']   ?? '');
                session_set('lastName',     $data['lastName']    ?? '');

                header('Location: /home');
                exit;
            } else {
                $errors[] = 'Login gagal: ' . $result['message'];
            }
        }
    }
}

$deviceId   = mt_rand(100000000000000, 999999999999999);
$page_title = 'Login';
$show_back  = false;
require __DIR__ . '/includes/layout_header.php';
?>

<div class="container py-4">
    <div class="tf-container">
        <form class="tf-form" action="/login" method="POST" autocomplete="off">
            <?= csrf_field() ?>
            <h1>Login</h1>

            <?php if ($success): ?>
                <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
            <?php endif; ?>
            <?php if ($errors): ?>
                <div class="alert alert-danger"><ul>
                    <?php foreach ($errors as $e): ?>
                        <li><?= htmlspecialchars($e) ?></li>
                    <?php endforeach; ?>
                </ul></div>
            <?php endif; ?>

            <div class="group-input">
                <label>Username / Nomor Telepon</label>
                <input type="text" name="username"
                       value="<?= htmlspecialchars($old['username'] ?? '') ?>"
                       placeholder="Masukkan username" required>
            </div>
            <div class="group-input">
                <label>Password / PIN</label>
                <div class="group-input-icon">
                    <input type="password" name="password" id="password"
                           placeholder="Masukkan password" required>
                    <span class="right-icon btn-show-pass">
                        <i class="icon-eye-off" id="toggle-password"></i>
                    </span>
                </div>
            </div>
            <div class="group-input">
                <label>Tipe Perangkat</label>
                <select name="deviceType" class="form-control">
                    <option value="android" <?= ($old['deviceType'] ?? '') === 'android' ? 'selected' : '' ?>>Android</option>
                    <option value="iphone"  <?= ($old['deviceType'] ?? '') === 'iphone'  ? 'selected' : '' ?>>iPhone</option>
                    <option value="web"     <?= ($old['deviceType'] ?? '') === 'web'     ? 'selected' : '' ?>>Web Browser</option>
                </select>
            </div>
            <input type="hidden" name="deviceId" value="<?= $deviceId ?>">

            <button type="submit" class="tf-btn accent large">Login</button>

            <p class="mt-3 text-center">
                <a href="/reset-password">Lupa Password?</a>
            </p>
            <p class="text-center">
                Belum punya akun? <a href="/register">Daftar sekarang</a>
            </p>
        </form>
    </div>
</div>

<script>
document.getElementById('toggle-password')?.addEventListener('click', function(){
    var inp = document.getElementById('password');
    if (inp.type === 'password') { inp.type = 'text'; this.classList.replace('icon-eye-off','icon-eye'); }
    else { inp.type = 'password'; this.classList.replace('icon-eye','icon-eye-off'); }
});
</script>

<?php require __DIR__ . '/includes/layout_footer.php'; ?>
