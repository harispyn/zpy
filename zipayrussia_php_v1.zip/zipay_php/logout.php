<?php
// ============================================================
//  logout.php – Proses logout
// ============================================================
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/session.php';
require_once __DIR__ . '/includes/api.php';

require_login();

$token = session_get('token', '');

// Panggil API logout (abaikan error)
if ($token) {
    api_post('/api/Auth/logout', [], $token);
}

session_destroy_all();
session_flash('success', 'Anda telah berhasil logout.');
header('Location: /login');
exit;
