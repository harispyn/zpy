<?php
// ============================================================
//  new-password.php – Set password/PIN baru + konfirmasi OTP
// ============================================================
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/session.php';
require_once __DIR__ . '/includes/api.php';

$errors  = [];
$success = session_flash_get('success');
$phoneNo = trim($_GET['phoneNo'] ?? '');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify()) { $errors[] = 'Token keamanan tidak valid.'; }
    else {
        $phoneNo       = trim($_POST['phoneNo']       ?? '');
        $newPin        = $_POST['newPin']             ?? '';
        $confirmNewPin = $_POST['confirmNewPin']      ?? '';
        $otp           = trim($_POST['otp']           ?? '');

        if ($phoneNo === '')       $errors[] = 'Nomor telepon wajib diisi.';
        if (strlen($newPin) < 6)  $errors[] = 'PIN baru minimal 6 karakter.';
        if ($newPin !== $confirmNewPin) $errors[] = 'Konfirmasi PIN tidak cocok.';
        if ($otp === '')           $errors[] = 'Kode OTP wajib diisi.';

        if (empty($errors)) {
            $result = api_post('/api/Merchant/VerifyChangePin', base_payload([
                'phoneNo'       => $phoneNo,
                'newPin'        => $newPin,
                'confirmNewPin' => $confirmNewPin,
                'otp'           => (int)$otp,
            ]));
            if ($result['ok']) {
                session_flash('success', 'Password baru berhasil diset. Silakan login.');
                header('Location: /login');
                exit;
            } else {
                $errors[] = 'Gagal: ' . $result['message'];
            }
        }
    }
}

$page_title = 'Password Baru';
$show_back  = true;
require __DIR__ . '/includes/layout_header.php';
?>

<div class="mt-4">
    <div class="tf-container">
        <form class="tf-form" action="/new-password" method="POST">
            <?= csrf_field() ?>
            <h1>Set Password Baru</h1>

            <?php if ($success): ?>
                <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
            <?php endif; ?>
            <?php if ($errors): ?>
                <div class="alert alert-danger"><ul>
                    <?php foreach ($errors as $e): ?><li><?= htmlspecialchars($e) ?></li><?php endforeach; ?>
                </ul></div>
            <?php endif; ?>

            <input type="hidden" name="phoneNo" value="<?= htmlspecialchars($phoneNo) ?>">

            <div class="group-input">
                <label>PIN Baru (min. 6 digit)</label>
                <input type="password" name="newPin" minlength="6" placeholder="Masukkan PIN baru" required>
            </div>
            <div class="group-input">
                <label>Konfirmasi PIN Baru</label>
                <input type="password" name="confirmNewPin" placeholder="Ulangi PIN baru" required>
            </div>
            <div class="group-input">
                <label>Kode OTP</label>
                <input type="text" name="otp" inputmode="numeric" maxlength="6"
                       placeholder="Masukkan kode OTP" required>
            </div>

            <button type="submit" class="tf-btn accent large">Simpan Password Baru</button>
        </form>
    </div>
</div>

<?php require __DIR__ . '/includes/layout_footer.php'; ?>
