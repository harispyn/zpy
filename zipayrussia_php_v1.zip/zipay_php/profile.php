<?php
// ============================================================
//  profile.php – Halaman profil user
// ============================================================
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/session.php';
require_once __DIR__ . '/includes/api.php';

require_login();

$firstName   = session_get('firstName', 'User');
$lastName    = session_get('lastName', '');
$phoneNumber = session_get('phoneNumber', '');
$token       = session_get('token', '');
$balance     = 0;

$result = api_post('/api/Multipocket/Balance', base_payload([
    'phoneNo'   => $phoneNumber,
    'userToken' => $token,
]));
if ($result['ok']) {
    $balance = $result['data']['result']['zipayPocket'] ?? 0;
}

$userName   = trim($firstName . ' ' . $lastName);
$page_title = 'Profil';
$show_back  = true;
require __DIR__ . '/includes/layout_header.php';
?>

<div class="mt-4">
    <div class="tf-container">
        <!-- Avatar -->
        <div class="text-center mb-4">
            <img src="/images/user/user1.jpg" alt="avatar"
                 style="width:80px;height:80px;border-radius:50%;object-fit:cover;">
            <h2 class="mt-2"><?= htmlspecialchars($userName) ?></h2>
            <p class="fw_4"><?= htmlspecialchars($phoneNumber) ?></p>
        </div>

        <!-- Saldo -->
        <div class="tf-balance-box mb-4">
            <div class="balance">
                <div class="inner-left text-center p-3">
                    <p>Saldo Zipay</p>
                    <h3>Rp <?= number_format((int)$balance, 0, ',', '.') ?></h3>
                </div>
            </div>
        </div>

        <!-- Menu Profil -->
        <ul class="profile-setting-list">
            <li>
                <a href="/settings" class="d-flex justify-content-between align-items-center py-3">
                    <div class="d-flex align-items-center gap-3">
                        <i class="icon-setting1"></i>
                        <span>Pengaturan</span>
                    </div>
                    <i class="icon-right"></i>
                </a>
            </li>
            <li>
                <a href="/change-password" class="d-flex justify-content-between align-items-center py-3">
                    <div class="d-flex align-items-center gap-3">
                        <i class="icon-lock2"></i>
                        <span>Ubah Password/PIN</span>
                    </div>
                    <i class="icon-right"></i>
                </a>
            </li>
            <li>
                <a href="/logout" onclick="return confirm('Yakin logout?')"
                   class="d-flex justify-content-between align-items-center py-3">
                    <div class="d-flex align-items-center gap-3">
                        <i class="icon-logout" style="color:#D32F2F;"></i>
                        <span style="color:#D32F2F;">Logout</span>
                    </div>
                    <i class="icon-right"></i>
                </a>
            </li>
        </ul>
    </div>
</div>

<!-- Bottom nav -->
<div class="bottom-navigation-bar">
    <div class="tf-container">
        <ul class="d-flex justify-content-around">
            <li><a href="/home"><i class="icon-home1"></i><span>Home</span></a></li>
            <li><a href="/profile" class="active"><i class="icon-user"></i><span>Profil</span></a></li>
            <li><a href="/qr-code"><i class="icon-my-qr"></i><span>QR</span></a></li>
            <li><a href="/settings"><i class="icon-setting1"></i><span>Setting</span></a></li>
        </ul>
    </div>
</div>

<?php require __DIR__ . '/includes/layout_footer.php'; ?>
