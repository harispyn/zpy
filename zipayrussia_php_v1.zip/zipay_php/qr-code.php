<?php
// ============================================================
//  qr-code.php – Tampilkan QR Code user
// ============================================================
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/session.php';

require_login();

$phoneNumber = session_get('phoneNumber', '');
$firstName   = session_get('firstName', 'User');

$page_title = 'QR Code Saya';
$show_back  = true;
require __DIR__ . '/includes/layout_header.php';
?>

<div class="mt-4">
    <div class="tf-container text-center">
        <h2>QR Code Saya</h2>
        <p class="fw_4 mb-4">Tunjukkan QR ini ke kasir untuk melakukan pembayaran.</p>

        <!-- Generate QR via Google Chart API (atau gunakan library qrcode.js) -->
        <div class="qr-wrapper" style="display:inline-block;padding:16px;background:#fff;border-radius:12px;box-shadow:0 2px 12px rgba(0,0,0,0.1);">
            <img id="qr-img"
                 src="https://api.qrserver.com/v1/create-qr-code/?size=220x220&data=<?= urlencode($phoneNumber) ?>"
                 alt="QR Code" style="width:220px;height:220px;">
        </div>

        <p class="mt-3 fw_6"><?= htmlspecialchars($firstName) ?></p>
        <p class="fw_4"><?= htmlspecialchars($phoneNumber) ?></p>

        <a href="/scan-qr" class="tf-btn outline large mt-3">Scan QR</a>
    </div>
</div>

<!-- Bottom nav -->
<div class="bottom-navigation-bar">
    <div class="tf-container">
        <ul class="d-flex justify-content-around">
            <li><a href="/home"><i class="icon-home1"></i><span>Home</span></a></li>
            <li><a href="/profile"><i class="icon-user"></i><span>Profil</span></a></li>
            <li><a href="/qr-code" class="active"><i class="icon-my-qr"></i><span>QR</span></a></li>
            <li><a href="/settings"><i class="icon-setting1"></i><span>Setting</span></a></li>
        </ul>
    </div>
</div>

<?php require __DIR__ . '/includes/layout_footer.php'; ?>
