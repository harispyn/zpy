<?php
// ============================================================
//  register.php – Halaman & proses registrasi
// ============================================================
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/session.php';
require_once __DIR__ . '/includes/api.php';

require_guest(); // redirect ke /home jika sudah login

$errors  = [];
$success = session_flash_get('success');
$old     = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validasi CSRF
    if (!csrf_verify()) {
        $errors[] = 'Token keamanan tidak valid. Muat ulang halaman.';
    } else {
        // Ambil & sanitasi input
        $firstName = trim($_POST['firstName'] ?? '');
        $lastName  = trim($_POST['lastName']  ?? '');
        $email     = trim($_POST['email']     ?? '');
        $phoneNo   = trim($_POST['phoneNo']   ?? '');
        $pin       = $_POST['pin']            ?? '';

        $old = compact('firstName','lastName','email','phoneNo');

        // Validasi
        if ($firstName === '') $errors[] = 'First name wajib diisi.';
        if ($lastName  === '') $errors[] = 'Last name wajib diisi.';
        if ($email     === '' || !filter_var($email, FILTER_VALIDATE_EMAIL))
            $errors[] = 'Email tidak valid.';
        if ($phoneNo === '') $errors[] = 'Nomor telepon wajib diisi.';
        if (strlen($pin) < 6) $errors[] = 'PIN minimal 6 karakter.';

        if (empty($errors)) {
            $result = api_post('/api/Multipocket/Register', base_payload([
                'firstName' => $firstName,
                'lastName'  => $lastName,
                'email'     => $email,
                'phoneNo'   => $phoneNo,
                'pin'       => $pin,
            ]));

            if ($result['ok']) {
                session_flash('success', 'Registrasi berhasil! Silakan aktivasi akun Anda.');
                header('Location: /activation?phoneNo=' . urlencode($phoneNo));
                exit;
            } else {
                $errors[] = 'Registrasi gagal: ' . $result['message'];
            }
        }
    }
}

$page_title = 'Daftar Akun';
$show_back  = true;
require __DIR__ . '/includes/layout_header.php';
?>

<div class="mt-3 register-section">
    <div class="tf-container">
        <form class="tf-form" action="/register" method="POST" autocomplete="off">
            <?= csrf_field() ?>
            <h1>Daftar Akun</h1>

            <?php if ($success): ?>
                <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
            <?php endif; ?>
            <?php if ($errors): ?>
                <div class="alert alert-danger"><ul>
                    <?php foreach ($errors as $e): ?>
                        <li><?= htmlspecialchars($e) ?></li>
                    <?php endforeach; ?>
                </ul></div>
            <?php endif; ?>

            <div class="group-input">
                <label>First Name</label>
                <input type="text" name="firstName" placeholder="Masukkan nama depan"
                       value="<?= htmlspecialchars($old['firstName'] ?? '') ?>" required>
            </div>
            <div class="group-input">
                <label>Last Name</label>
                <input type="text" name="lastName" placeholder="Masukkan nama belakang"
                       value="<?= htmlspecialchars($old['lastName'] ?? '') ?>" required>
            </div>
            <div class="group-input">
                <label>Email</label>
                <input type="email" name="email" placeholder="Masukkan email"
                       value="<?= htmlspecialchars($old['email'] ?? '') ?>" required>
            </div>
            <div class="group-input">
                <label>Nomor Telepon</label>
                <input type="tel" name="phoneNo" placeholder="Contoh: 08123456789"
                       value="<?= htmlspecialchars($old['phoneNo'] ?? '') ?>" required>
            </div>
            <div class="group-input">
                <label>PIN (min. 6 digit)</label>
                <input type="password" name="pin" placeholder="Masukkan PIN" minlength="6" required>
            </div>

            <button type="submit" class="tf-btn accent large">Buat Akun</button>

            <p class="mt-3 text-center">
                Sudah punya akun? <a href="/login">Login di sini</a>
            </p>
        </form>
    </div>
</div>

<?php require __DIR__ . '/includes/layout_footer.php'; ?>
