<?php
// ============================================================
//  reset-password.php – Request reset password / PIN
// ============================================================
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/session.php';
require_once __DIR__ . '/includes/api.php';

$errors  = [];
$success = session_flash_get('success');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify()) { $errors[] = 'Token keamanan tidak valid.'; }
    else {
        $phoneNo = trim($_POST['phoneNo'] ?? '');
        if ($phoneNo === '') { $errors[] = 'Nomor telepon wajib diisi.'; }
        else {
            $result = api_post('/api/Merchant/ChangePin', base_payload(['phoneNo' => $phoneNo]));
            if ($result['ok']) {
                session_flash('success', 'Instruksi reset dikirim ke nomor Anda.');
                header('Location: /new-password?phoneNo=' . urlencode($phoneNo));
                exit;
            } else {
                $errors[] = 'Gagal memproses permintaan: ' . $result['message'];
            }
        }
    }
}

$page_title = 'Reset Password';
$show_back  = true;
require __DIR__ . '/includes/layout_header.php';
?>

<div class="mt-4">
    <div class="tf-container">
        <form class="tf-form" action="/reset-password" method="POST">
            <?= csrf_field() ?>
            <h1>Reset Password / PIN</h1>
            <p class="fw_4">Masukkan nomor telepon Anda untuk menerima kode OTP reset.</p>

            <?php if ($success): ?>
                <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
            <?php endif; ?>
            <?php if ($errors): ?>
                <div class="alert alert-danger"><ul>
                    <?php foreach ($errors as $e): ?><li><?= htmlspecialchars($e) ?></li><?php endforeach; ?>
                </ul></div>
            <?php endif; ?>

            <div class="group-input">
                <label>Nomor Telepon</label>
                <input type="tel" name="phoneNo" placeholder="Contoh: 08123456789" required>
            </div>

            <button type="submit" class="tf-btn accent large">Kirim Kode OTP</button>
            <p class="mt-3 text-center"><a href="/login">Kembali ke Login</a></p>
        </form>
    </div>
</div>

<?php require __DIR__ . '/includes/layout_footer.php'; ?>
