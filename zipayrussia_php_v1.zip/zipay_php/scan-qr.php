<?php
// ============================================================
//  scan-qr.php – Halaman scan QR
// ============================================================
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/session.php';

require_login();

$page_title = 'Scan QR';
$show_back  = true;
require __DIR__ . '/includes/layout_header.php';
?>

<div class="mt-4">
    <div class="tf-container text-center">
        <h2>Scan QR Code</h2>
        <p class="fw_4 mb-4">Arahkan kamera ke QR Code merchant.</p>

        <div id="qr-reader" style="width:100%;max-width:400px;margin:0 auto;"></div>
        <div id="qr-result" class="mt-3"></div>

        <div id="manual-input" class="mt-4">
            <p class="fw_4">Atau masukkan kode QR secara manual:</p>
            <form id="qr-form">
                <div class="group-input">
                    <input type="text" id="qrCode" name="qrCode" placeholder="Paste kode QR di sini">
                </div>
                <button type="submit" class="tf-btn accent large">Proses QR</button>
            </form>
        </div>

        <div id="qr-response" class="mt-3"></div>
    </div>
</div>

<!-- Bottom nav -->
<div class="bottom-navigation-bar">
    <div class="tf-container">
        <ul class="d-flex justify-content-around">
            <li><a href="/home"><i class="icon-home1"></i><span>Home</span></a></li>
            <li><a href="/profile"><i class="icon-user"></i><span>Profil</span></a></li>
            <li><a href="/qr-code"><i class="icon-my-qr"></i><span>QR</span></a></li>
            <li><a href="/settings"><i class="icon-setting1"></i><span>Setting</span></a></li>
        </ul>
    </div>
</div>

<script>
document.getElementById('qr-form').addEventListener('submit', function(e) {
    e.preventDefault();
    var qrCode  = document.getElementById('qrCode').value.trim();
    var resDiv  = document.getElementById('qr-response');
    if (!qrCode) { resDiv.innerHTML = '<div class="alert alert-danger">QR Code tidak boleh kosong.</div>'; return; }

    resDiv.innerHTML = '<p>Memproses...</p>';

    fetch('/process-qr', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: '_token=' + encodeURIComponent(document.querySelector('meta[name="csrf-token"]')?.content || '') +
              '&qrCode=' + encodeURIComponent(qrCode)
    })
    .then(r => r.json())
    .then(data => {
        if (data.error) {
            resDiv.innerHTML = '<div class="alert alert-danger">' + data.error + '</div>';
        } else {
            resDiv.innerHTML = '<div class="alert alert-success">QR berhasil diproses!</div>' +
                               '<pre style="font-size:12px;">' + JSON.stringify(data, null, 2) + '</pre>';
        }
    })
    .catch(() => {
        resDiv.innerHTML = '<div class="alert alert-danger">Terjadi kesalahan jaringan.</div>';
    });
});
</script>

<?php require __DIR__ . '/includes/layout_footer.php'; ?>
