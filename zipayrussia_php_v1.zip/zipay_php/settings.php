<?php
// ============================================================
//  settings.php – Halaman pengaturan
// ============================================================
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/session.php';

require_login();

$page_title = 'Pengaturan';
$show_back  = true;
require __DIR__ . '/includes/layout_header.php';
?>

<div class="mt-4">
    <div class="tf-container">
        <h2 class="mb-4">Pengaturan</h2>

        <ul class="profile-setting-list">
            <li>
                <a href="/change-password" class="d-flex justify-content-between align-items-center py-3">
                    <div class="d-flex align-items-center gap-3">
                        <i class="icon-lock2"></i><span>Ubah Password / PIN</span>
                    </div>
                    <i class="icon-right"></i>
                </a>
            </li>
            <li>
                <a href="/profile" class="d-flex justify-content-between align-items-center py-3">
                    <div class="d-flex align-items-center gap-3">
                        <i class="icon-user"></i><span>Profil</span>
                    </div>
                    <i class="icon-right"></i>
                </a>
            </li>
            <li>
                <a href="/logout" onclick="return confirm('Yakin ingin logout?')"
                   class="d-flex justify-content-between align-items-center py-3">
                    <div class="d-flex align-items-center gap-3">
                        <i class="icon-logout" style="color:#D32F2F;"></i>
                        <span style="color:#D32F2F;">Logout</span>
                    </div>
                    <i class="icon-right"></i>
                </a>
            </li>
        </ul>
    </div>
</div>

<!-- Bottom nav -->
<div class="bottom-navigation-bar">
    <div class="tf-container">
        <ul class="d-flex justify-content-around">
            <li><a href="/home"><i class="icon-home1"></i><span>Home</span></a></li>
            <li><a href="/profile"><i class="icon-user"></i><span>Profil</span></a></li>
            <li><a href="/qr-code"><i class="icon-my-qr"></i><span>QR</span></a></li>
            <li><a href="/settings" class="active"><i class="icon-setting1"></i><span>Setting</span></a></li>
        </ul>
    </div>
</div>

<?php require __DIR__ . '/includes/layout_footer.php'; ?>
