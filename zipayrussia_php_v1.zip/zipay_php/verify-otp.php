<?php
// ============================================================
//  verify-otp.php – Verifikasi OTP & resend OTP
// ============================================================
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/session.php';
require_once __DIR__ . '/includes/api.php';

$errors  = [];
$success = session_flash_get('success');
$phoneNo = trim($_GET['phoneNo'] ?? '');

// ── Resend OTP ──────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'resend') {
    if (!csrf_verify()) { $errors[] = 'Token keamanan tidak valid.'; }
    else {
        $phoneNo = trim($_POST['phoneNo'] ?? '');
        $result  = api_post('/api/Multipocket/Resend', base_payload(['phoneNo' => $phoneNo]));
        if ($result['ok']) {
            session_flash('success', 'OTP berhasil dikirim ulang!');
            header('Location: /verify-otp?phoneNo=' . urlencode($phoneNo));
            exit;
        } else {
            $errors[] = 'Gagal mengirim ulang OTP: ' . $result['message'];
        }
    }
}

// ── Verify OTP ──────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($_POST['action'])) {
    if (!csrf_verify()) { $errors[] = 'Token keamanan tidak valid.'; }
    else {
        $phoneNo = trim($_POST['phoneNo'] ?? '');
        $otpArr  = $_POST['otp'] ?? [];

        if (count($otpArr) !== 6 || in_array('', $otpArr)) {
            $errors[] = 'Masukkan 6 digit OTP.';
        } else {
            $otpCode = (int) implode('', $otpArr);
            $result  = api_post('/api/Multipocket/Verify', base_payload([
                'phoneNo' => $phoneNo,
                'otpcode' => $otpCode,
            ]));

            if ($result['ok']) {
                header('Location: /verify-success');
                exit;
            } else {
                $errors[] = 'OTP tidak valid: ' . $result['message'];
            }
        }
    }
}

$page_title = 'Verifikasi OTP';
$show_back  = true;
require __DIR__ . '/includes/layout_header.php';
?>

<div class="mt-5">
    <div class="tf-container">
        <h3 class="text-center mb-3">Masukkan Kode OTP</h3>
        <p class="text-center fw_4">Kode OTP telah dikirim ke nomor <strong><?= htmlspecialchars($phoneNo) ?></strong></p>

        <?php if ($success): ?>
            <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
        <?php endif; ?>
        <?php if ($errors): ?>
            <div class="alert alert-danger"><ul>
                <?php foreach ($errors as $e): ?>
                    <li><?= htmlspecialchars($e) ?></li>
                <?php endforeach; ?>
            </ul></div>
        <?php endif; ?>

        <!-- Form verifikasi OTP -->
        <form class="tf-form tf-form-verify" action="/verify-otp" method="POST">
            <?= csrf_field() ?>
            <input type="hidden" name="phoneNo" value="<?= htmlspecialchars($phoneNo) ?>">

            <div class="d-flex group-input-verify justify-content-center mb-4">
                <?php for ($i = 0; $i < 6; $i++): ?>
                    <input type="tel" maxlength="1" pattern="[0-9]"
                           class="input-verify" name="otp[]"
                           inputmode="numeric" required>
                <?php endfor; ?>
            </div>

            <button type="submit" class="tf-btn accent large">Verifikasi</button>
        </form>

        <!-- Form resend OTP -->
        <form action="/verify-otp" method="POST" class="mt-3 text-center">
            <?= csrf_field() ?>
            <input type="hidden" name="phoneNo" value="<?= htmlspecialchars($phoneNo) ?>">
            <input type="hidden" name="action" value="resend">
            <button type="submit" class="tf-btn outline small">Kirim Ulang OTP</button>
        </form>
    </div>
</div>

<script>
// Auto-focus next input OTP
document.querySelectorAll('.input-verify').forEach(function(inp, idx, all) {
    inp.addEventListener('input', function() {
        this.value = this.value.replace(/[^0-9]/g, '');
        if (this.value.length === 1 && idx < all.length - 1) {
            all[idx + 1].focus();
        }
    });
    inp.addEventListener('keydown', function(e) {
        if (e.key === 'Backspace' && this.value === '' && idx > 0) {
            all[idx - 1].focus();
        }
    });
});
</script>

<?php require __DIR__ . '/includes/layout_footer.php'; ?>
