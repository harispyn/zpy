-- ============================================================
-- zipay_database.sql – Skema database Zipay Russia (PHP murni)
-- Jalankan: mysql -u root -p < zipay_database.sql
-- ============================================================

CREATE DATABASE IF NOT EXISTS `zipay_db`
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE `zipay_db`;

-- Tabel sessions (opsional, jika pakai DB session)
CREATE TABLE IF NOT EXISTS `php_sessions` (
    `id`          VARCHAR(128) NOT NULL,
    `data`        MEDIUMTEXT   NOT NULL,
    `last_access` INT UNSIGNED NOT NULL,
    PRIMARY KEY (`id`),
    KEY `last_access_idx` (`last_access`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabel activity log (opsional)
CREATE TABLE IF NOT EXISTS `activity_log` (
    `id`         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `phone_no`   VARCHAR(20)  NULL,
    `action`     VARCHAR(100) NOT NULL,
    `ip`         VARCHAR(45)  NULL,
    `created_at` TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `phone_idx` (`phone_no`),
    KEY `created_idx` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
