<?php
// ============================================================
//  includes/layout_header.php – Header HTML (layout global)
//  Param yang harus diset sebelum include:
//    $page_title  (string)
//    $show_back   (bool, default false)
// ============================================================
$page_title = $page_title ?? APP_NAME;
$show_back  = $show_back  ?? false;
// pastikan session sudah aktif (aman dipanggil berkali-kali)
if (function_exists('session_init')) session_init();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, viewport-fit=cover"/>
    <meta name="csrf-token" content="<?= htmlspecialchars(csrf_token()) ?>"/>
    <title><?= htmlspecialchars($page_title) ?> – <?= APP_NAME ?></title>
    <link rel="shortcut icon" href="/favicon.ico"/>
    <link rel="apple-touch-icon-precomposed" href="/images/logo.png"/>
    <link rel="stylesheet" href="/fonts/fonts.css"/>
    <link rel="stylesheet" href="/fonts/icons-alipay.css"/>
    <link rel="stylesheet" href="/styles/bootstrap.css"/>
    <link rel="stylesheet" href="/styles/swiper-bundle.min.css"/>
    <link rel="stylesheet" href="/styles/styles.css"/>
    <link rel="manifest" href="/_manifest.json"/>
    <style>
        .alert { padding: 12px 16px; border-radius: 8px; margin-bottom: 12px; font-size: 14px; }
        .alert-danger  { background: #fdecea; color: #b00020; border: 1px solid #f5c6cb; }
        .alert-success { background: #e8f5e9; color: #1b5e20; border: 1px solid #c3e6cb; }
        .alert ul { margin: 0; padding-left: 18px; }
        .lang-bar { position: fixed; top: 0; right: 0; z-index: 999; background: rgba(0,0,0,0.6);
                    padding: 4px 10px; border-radius: 0 0 0 8px; display: flex; gap: 8px; }
        .lang-bar a { color: #fff; font-size: 11px; text-decoration: none; }
        .lang-bar a:hover { text-decoration: underline; }
        .field-error { color: #b00020; font-size: 12px; margin-top: 4px; }
    </style>
</head>
<body>
<!-- Language bar -->
<div class="lang-bar">
    <a href="?lang=id">ID</a>
    <a href="?lang=en">EN</a>
    <a href="?lang=ru">RU</a>
</div>

<?php if ($show_back): ?>
<!-- Header with back button -->
<div class="header">
    <div class="tf-container">
        <div class="tf-statusbar br-none d-flex justify-content-center align-items-center">
            <a href="javascript:history.back()" class="back-btn"><i class="icon-left"></i></a>
            <?php if (!empty($page_title)): ?>
                <h3><?= htmlspecialchars($page_title) ?></h3>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Preload spinner -->
<div class="preload preload-container" id="preload">
    <div class="preload-logo">
        <div class="spinner"></div>
    </div>
</div>
