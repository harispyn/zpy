<?php
// ============================================================
//  process-qr.php – AJAX endpoint: proses QR Code
// ============================================================
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/session.php';
require_once __DIR__ . '/includes/api.php';

header('Content-Type: application/json');

// Harus login
if (!is_logged_in()) {
    http_response_code(401);
    echo json_encode(['error' => 'Sesi tidak valid. Silakan login kembali.']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed.']);
    exit;
}

// Verifikasi CSRF token
if (!csrf_verify()) {
    http_response_code(403);
    echo json_encode(['error' => 'Token keamanan tidak valid.']);
    exit;
}

$qrCode = trim($_POST['qrCode'] ?? '');
if ($qrCode === '') {
    http_response_code(422);
    echo json_encode(['error' => 'QR Code tidak boleh kosong.']);
    exit;
}

$token  = session_get('token', '');
$result = api_post('/api/Qris/IssuerScan', ['qrCode' => $qrCode], $token);

if ($result['ok']) {
    echo json_encode($result['data']);
} else {
    http_response_code($result['status'] ?: 500);
    echo json_encode(['error' => $result['message']]);
}
exit;
