<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\RequestException;
use GuzzleHttp\Exception\ConnectException;
use Illuminate\Support\Facades\Crypt;

class ActivationController extends Controller
{
    private function makeClient(): Client
    {
        return new Client([
            'timeout'         => 30,
            'connect_timeout' => 10,
            'http_errors'     => true,
            'verify'          => false,
        ]);
    }

    private function parseApiError(RequestException $e, string $context = 'API'): string
    {
        $statusCode = $e->hasResponse() ? $e->getResponse()->getStatusCode() : 0;
        $message    = null;

        if ($e->hasResponse()) {
            try {
                $body    = $e->getResponse()->getBody()->getContents();
                $json    = json_decode($body, true);
                $message = $json['message'] ?? $json['Message'] ?? $json['error'] ?? null;
            } catch (\Throwable $t) {}
        }

        if (empty($message)) {
            $message = match($statusCode) {
                400 => 'Data tidak valid.',
                401 => 'Autentikasi gagal.',
                403 => 'Akses ditolak.',
                404 => 'Endpoint tidak ditemukan.',
                422 => 'Data tidak dapat diproses.',
                500 => 'Kesalahan server API.',
                502 => 'API Gateway error (Bad Gateway).',
                503 => 'Server API tidak tersedia.',
                0   => 'Tidak dapat terhubung ke server API.',
                default => "HTTP {$statusCode}.",
            };
        }

        \Log::error("{$context} Error", ['status' => $statusCode, 'message' => $message]);
        return "Error {$statusCode}: {$message}";
    }

    public function index(string $phoneNo = '')
    {
        $deviceID = $phoneNo ? Crypt::encryptString($phoneNo) : '';
        return view('activation', compact('phoneNo', 'deviceID'));
    }

    public function activate(Request $request)
    {
        $request->validate(['phoneNo' => 'required|string']);

        try {
            $client   = $this->makeClient();
            $baseUrl  = rtrim(config('services.multipocket.base_url'), '/');
            $endpoint = $baseUrl . '/api/Multipocket/Activation';
            $deviceID = Crypt::encryptString($request->phoneNo);

            $client->post($endpoint, [
                'json'    => [
                    'mid'           => config('services.multipocket.mid'),
                    'merchantToken' => config('services.multipocket.merchant_token'),
                    'phoneNo'       => $request->phoneNo,
                    'deviceID'      => $request->deviceID ?? $deviceID,
                ],
                'headers' => [
                    'Accept'       => 'application/json',
                    'Content-Type' => 'application/json',  // FIX
                ],
            ]);

            return redirect()
                ->route('otp.show', ['phoneNo' => $request->phoneNo])
                ->with('success', 'Aktivasi berhasil! Silakan verifikasi OTP.');

        } catch (ConnectException $e) {
            return back()->withErrors(['activation' => 'Tidak dapat terhubung ke server API.']);
        } catch (RequestException $e) {
            return back()->withErrors(['activation' => $this->parseApiError($e, 'Activation')]);
        } catch (\Throwable $e) {
            \Log::error('Activation Unexpected: ' . $e->getMessage());
            return back()->withErrors(['activation' => 'Kesalahan: ' . $e->getMessage()]);
        }
    }

    public function showVerifyForm(string $phoneNo)
    {
        return view('verify-otp', compact('phoneNo'));
    }

    public function verifyOTP(Request $request)
    {
        $request->validate([
            'phoneNo' => 'required|string',
            'otp'     => 'required|array|size:6',
            'otp.*'   => 'required|digits:1',
        ]);

        $otpCode = implode('', $request->otp);

        try {
            $client   = $this->makeClient();
            $baseUrl  = rtrim(config('services.multipocket.base_url'), '/');
            $endpoint = $baseUrl . '/api/Multipocket/Verify';

            $client->post($endpoint, [
                'json'    => [
                    'mid'           => config('services.multipocket.mid'),
                    'merchantToken' => config('services.multipocket.merchant_token'),
                    'phoneNo'       => $request->phoneNo,
                    'otpcode'       => (int) $otpCode,
                ],
                'headers' => [
                    'Accept'       => 'application/json',
                    'Content-Type' => 'application/json',  // FIX
                ],
            ]);

            return view('verify-success');

        } catch (ConnectException $e) {
            return back()->withErrors(['otp' => 'Tidak dapat terhubung ke server API.']);
        } catch (RequestException $e) {
            return back()->withErrors(['otp' => $this->parseApiError($e, 'VerifyOTP')]);
        } catch (\Throwable $e) {
            \Log::error('VerifyOTP Unexpected: ' . $e->getMessage());
            return back()->withErrors(['otp' => 'Kesalahan: ' . $e->getMessage()]);
        }
    }

    public function resendOTP(Request $request)
    {
        $request->validate(['phoneNo' => 'required|string']);

        try {
            $client   = $this->makeClient();
            $baseUrl  = rtrim(config('services.multipocket.base_url'), '/');
            $endpoint = $baseUrl . '/api/Multipocket/Resend';

            $client->post($endpoint, [
                'json'    => [
                    'mid'           => config('services.multipocket.mid'),
                    'merchantToken' => config('services.multipocket.merchant_token'),
                    'phoneNo'       => $request->phoneNo,
                ],
                'headers' => [
                    'Accept'       => 'application/json',
                    'Content-Type' => 'application/json',  // FIX
                ],
            ]);

            return redirect()
                ->route('otp.show', ['phoneNo' => $request->phoneNo])
                ->with('success', 'OTP berhasil dikirim ulang!');

        } catch (ConnectException $e) {
            return back()->withErrors(['resend' => 'Tidak dapat terhubung ke server API.']);
        } catch (RequestException $e) {
            return back()->withErrors(['resend' => $this->parseApiError($e, 'ResendOTP')]);
        } catch (\Throwable $e) {
            \Log::error('ResendOTP Unexpected: ' . $e->getMessage());
            return back()->withErrors(['resend' => 'Kesalahan: ' . $e->getMessage()]);
        }
    }
}
