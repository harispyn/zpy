<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\RequestException;
use GuzzleHttp\Exception\ConnectException;

class HomeController extends Controller
{
    private function makeClient(): Client
    {
        return new Client([
            'timeout'         => 30,
            'connect_timeout' => 10,
            'http_errors'     => true,
            'verify'          => false,
        ]);
    }

    public function index()
    {
        $data = Session::get('api_response');

        // Jika session tidak ada, redirect ke login
        if (empty($data)) {
            return redirect()->route('login')->with('error', 'Sesi habis. Silakan login kembali.');
        }

        // Redirect ke aktivasi jika phone belum diverifikasi
        if (isset($data['isPhoneVerified']) && strtolower($data['isPhoneVerified']) === 'false') {
            return redirect()
                ->route('activation.index', ['phoneNo' => $data['phoneNumber'] ?? ''])
                ->with('success', 'Registrasi berhasil! Silakan aktivasi akun.');
        }

        $balance = 0;

        try {
            $client   = $this->makeClient();
            $baseUrl  = rtrim(config('services.multipocket.base_url'), '/');
            $endpoint = $baseUrl . '/api/Multipocket/Balance';

            $response = $client->post($endpoint, [
                'json'    => [
                    'mid'           => config('services.multipocket.mid'),
                    'merchantToken' => config('services.multipocket.merchant_token'),
                    'phoneNo'       => $data['phoneNumber'] ?? '',
                    'userToken'     => $data['token'] ?? Session::get('token', ''),
                ],
                'headers' => [
                    'Accept'       => 'application/json',
                    'Content-Type' => 'application/json',  // FIX
                ],
            ]);

            $result  = json_decode($response->getBody()->getContents(), true);
            $balance = $result['result']['zipayPocket'] ?? 0;

        } catch (ConnectException $e) {
            \Log::warning('Home Balance ConnectException: ' . $e->getMessage());
            // Tampilkan home dengan balance 0 jika API tidak tersedia
        } catch (RequestException $e) {
            $statusCode = $e->hasResponse() ? $e->getResponse()->getStatusCode() : 0;
            \Log::warning("Home Balance API Error {$statusCode}: " . $e->getMessage());
            // Tampilkan home dengan balance 0
        } catch (\Throwable $e) {
            \Log::error('Home Unexpected: ' . $e->getMessage());
        }

        $firstName = $data['firstName'] ?? 'User';
        $lastName  = $data['lastName']  ?? '';

        return view('home', [
            'user'    => trim("{$firstName} {$lastName}"),
            'balance' => $balance,
        ]);
    }
}
