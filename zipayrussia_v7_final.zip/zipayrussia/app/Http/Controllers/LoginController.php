<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\RequestException;
use GuzzleHttp\Exception\ConnectException;
use Illuminate\Support\Facades\Session;

class LoginController extends Controller
{
    /**
     * Buat Guzzle client dengan konfigurasi standar
     */
    private function makeClient(): Client
    {
        return new Client([
            'timeout'         => 30,
            'connect_timeout' => 10,
            'http_errors'     => true,
            'verify'          => false,
        ]);
    }

    /**
     * Parse error dari API response secara aman
     */
    private function parseApiError(RequestException $e, string $context = 'API'): string
    {
        $statusCode = $e->hasResponse() ? $e->getResponse()->getStatusCode() : 0;
        $message    = null;

        if ($e->hasResponse()) {
            try {
                $body    = $e->getResponse()->getBody()->getContents();
                $json    = json_decode($body, true);
                $message = $json['message'] ?? $json['Message'] ?? $json['error'] ?? null;
            } catch (\Throwable $t) {}
        }

        if (empty($message)) {
            $message = match($statusCode) {
                400 => 'Data tidak valid.',
                401 => 'Username atau password salah.',
                403 => 'Akses ditolak.',
                404 => 'Endpoint API tidak ditemukan.',
                422 => 'Data tidak dapat diproses.',
                429 => 'Terlalu banyak percobaan. Coba lagi nanti.',
                500 => 'Kesalahan server API internal.',
                502 => 'API Gateway error. Periksa koneksi ke server API.',
                503 => 'Server API tidak tersedia.',
                504 => 'Server API timeout.',
                0   => 'Tidak dapat terhubung ke server API.',
                default => "Server merespon HTTP {$statusCode}.",
            };
        }

        \Log::error("{$context} Error", ['status' => $statusCode, 'message' => $message]);
        return "Error {$statusCode}: {$message}";
    }

    public function index(Request $request)
    {
        return view('login', ['deviceId' => mt_rand(100000000000000, 999999999999999)]);
    }

    public function store(Request $request)
    {
        $request->validate([
            'username'   => 'required|string',
            'password'   => 'required|string',
            'deviceType' => 'required|string',
            'deviceId'   => 'required|integer',
        ]);

        try {
            $client   = $this->makeClient();
            $baseUrl  = rtrim(config('services.multipocket.base_url'), '/');
            $endpoint = $baseUrl . '/api/Auth/Login';

            $response = $client->post($endpoint, [
                'json'    => [
                    'username'   => $request->username,
                    'password'   => $request->password,
                    'deviceType' => $request->deviceType,
                    'deviceId'   => $request->deviceId,
                ],
                'headers' => [
                    'Accept'       => 'application/json',
                    'Content-Type' => 'application/json',  // FIX
                ],
            ]);

            $responseBody = json_decode($response->getBody()->getContents(), true);
            $data = $responseBody['result'] ?? $responseBody;

            if (isset($data['token'])) {
                Session::put('api_response', $data);
                Session::put('token', $data['token']);
                return redirect()->route('home');
            }

            return redirect()->route('home')->with('success', 'Login berhasil!');

        } catch (ConnectException $e) {
            return back()->withErrors(['login' => 'Tidak dapat terhubung ke server API.'])->withInput();
        } catch (RequestException $e) {
            return back()->withErrors(['login' => $this->parseApiError($e, 'Login')])->withInput();
        } catch (\Throwable $e) {
            \Log::error('Login Unexpected: ' . $e->getMessage());
            return back()->withErrors(['login' => 'Kesalahan tidak terduga: ' . $e->getMessage()])->withInput();
        }
    }

    public function logout(Request $request)
    {
        $token = Session::get('token');

        if (!$token) {
            return redirect()->route('login')->with('error', 'Anda belum login.');
        }

        try {
            $client   = $this->makeClient();
            $baseUrl  = rtrim(config('services.multipocket.base_url'), '/');
            $endpoint = $baseUrl . '/api/Auth/logout';

            $client->post($endpoint, [
                'headers' => [
                    'Accept'        => 'application/json',
                    'Authorization' => "Bearer {$token}",
                ],
            ]);
        } catch (\Throwable $e) {
            // Tetap logout meski API gagal
            \Log::warning('Logout API error (ignored): ' . $e->getMessage());
        }

        Session::forget(['api_response', 'token']);
        return redirect()->route('login')->with('success', 'Anda telah berhasil logout.');
    }

    public function resetPassword(Request $request)
    {
        $request->validate(['phoneNo' => 'required|string']);

        try {
            $client   = $this->makeClient();
            $baseUrl  = rtrim(config('services.multipocket.base_url'), '/');
            $endpoint = $baseUrl . '/api/Merchant/ChangePin';

            $client->post($endpoint, [
                'json'    => [
                    'mid'           => config('services.multipocket.mid'),
                    'merchantToken' => config('services.multipocket.merchant_token'),
                    'phoneNo'       => $request->phoneNo,
                ],
                'headers' => [
                    'Accept'       => 'application/json',
                    'Content-Type' => 'application/json',  // FIX
                ],
            ]);

            return redirect()->route('password.verifyreset', ['phoneNo' => $request->phoneNo])
                ->with('success', 'Instruksi reset dikirim ke nomor Anda.');

        } catch (ConnectException $e) {
            return back()->withErrors(['phoneNo' => 'Tidak dapat terhubung ke server API.']);
        } catch (RequestException $e) {
            return back()->withErrors(['phoneNo' => $this->parseApiError($e, 'ResetPassword')]);
        } catch (\Throwable $e) {
            return back()->withErrors(['phoneNo' => 'Kesalahan: ' . $e->getMessage()]);
        }
    }

    public function verifyReset(Request $request)
    {
        return view('new-password', ['phoneNo' => $request->phoneNo]);
    }

    public function confirmPassword(Request $request)
    {
        $request->validate([
            'phoneNo'        => 'required|string',
            'newPin'         => 'required|string|min:6|max:20',
            'confirmNewPin'  => 'required|string|same:newPin',
            'otp'            => 'required|integer',
        ]);

        try {
            $client   = $this->makeClient();
            $baseUrl  = rtrim(config('services.multipocket.base_url'), '/');
            $endpoint = $baseUrl . '/api/Merchant/VerifyChangePin';

            $client->post($endpoint, [
                'json'    => [
                    'mid'           => config('services.multipocket.mid'),
                    'merchantToken' => config('services.multipocket.merchant_token'),
                    'phoneNo'       => $request->phoneNo,
                    'newPin'        => $request->newPin,
                    'confirmNewPin' => $request->confirmNewPin,
                    'otp'           => $request->otp,
                ],
                'headers' => [
                    'Accept'       => 'application/json',
                    'Content-Type' => 'application/json',  // FIX
                ],
            ]);

            return redirect()->route('password.confirmview')
                ->with('success', 'Password baru berhasil diset.');

        } catch (ConnectException $e) {
            return back()->withErrors(['otp' => 'Tidak dapat terhubung ke server API.']);
        } catch (RequestException $e) {
            return back()->withErrors(['otp' => $this->parseApiError($e, 'ConfirmPassword')]);
        } catch (\Throwable $e) {
            return back()->withErrors(['otp' => 'Kesalahan: ' . $e->getMessage()]);
        }
    }

    public function confirmPasswordView()
    {
        return view('password-confirm');
    }
}
