<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\RequestException;
use GuzzleHttp\Exception\ConnectException;
use Illuminate\Support\Facades\Session;

class QRController extends Controller
{
    private function makeClient(): Client
    {
        return new Client([
            'timeout'         => 30,
            'connect_timeout' => 10,
            'http_errors'     => true,
            'verify'          => false,
        ]);
    }

    public function process(Request $request)
    {
        $request->validate(['qrCode' => 'required|string']);

        $token = Session::get('token');
        if (!$token) {
            return response()->json(['error' => 'Sesi tidak valid. Silakan login kembali.'], 401);
        }

        try {
            $client   = $this->makeClient();
            $baseUrl  = rtrim(config('services.multipocket.base_url'), '/');
            $endpoint = $baseUrl . '/api/Qris/IssuerScan';

            $response = $client->post($endpoint, [
                'json'    => ['qrCode' => $request->qrCode],
                'headers' => [
                    'Accept'        => 'application/json',
                    'Content-Type'  => 'application/json',  // FIX
                    'Authorization' => "Bearer {$token}",
                ],
            ]);

            $data = json_decode($response->getBody()->getContents(), true);
            return response()->json($data);

        } catch (ConnectException $e) {
            \Log::error('QR ConnectException: ' . $e->getMessage());
            return response()->json([
                'error' => 'Tidak dapat terhubung ke server API.',
            ], 503);

        } catch (RequestException $e) {
            $statusCode = $e->hasResponse() ? $e->getResponse()->getStatusCode() : 0;
            $message    = null;

            if ($e->hasResponse()) {
                try {
                    $body    = $e->getResponse()->getBody()->getContents();
                    $json    = json_decode($body, true);
                    $message = $json['message'] ?? $json['Message'] ?? $json['error'] ?? null;
                } catch (\Throwable $t) {}
            }

            $message = $message ?? match($statusCode) {
                401 => 'Token tidak valid. Silakan login kembali.',
                403 => 'Akses ditolak.',
                404 => 'QR Code tidak ditemukan.',
                422 => 'QR Code tidak valid.',
                502 => 'API Gateway error.',
                default => "HTTP {$statusCode}.",
            };

            \Log::error('QR API Error', ['status' => $statusCode, 'message' => $message]);
            return response()->json(['error' => $message], $statusCode ?: 500);

        } catch (\Throwable $e) {
            \Log::error('QR Unexpected: ' . $e->getMessage());
            return response()->json(['error' => 'Kesalahan tidak terduga.'], 500);
        }
    }
}
