<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\RequestException;
use GuzzleHttp\Exception\ConnectException;

class RegisterController extends Controller
{
    /**
     * Buat Guzzle client dengan konfigurasi standar
     */
    private function makeClient(): Client
    {
        return new Client([
            'timeout'         => 30,
            'connect_timeout' => 10,
            'http_errors'     => true,
            'verify'          => false, // disable SSL verify untuk dev API
        ]);
    }

    /**
     * Parse error message dari API response
     */
    private function parseError(RequestException $e): array
    {
        $statusCode = $e->hasResponse() ? $e->getResponse()->getStatusCode() : 0;
        $body       = '';

        if ($e->hasResponse()) {
            try {
                $body = $e->getResponse()->getBody()->getContents();
                $json = json_decode($body, true);
                $message = $json['message']
                    ?? $json['Message']
                    ?? $json['error']
                    ?? $json['Error']
                    ?? null;
            } catch (\Throwable $t) {
                $message = null;
            }
        }

        if (empty($message)) {
            $message = match($statusCode) {
                400 => 'Data tidak valid atau format permintaan salah.',
                401 => 'Autentikasi gagal. Periksa MID dan Merchant Token.',
                403 => 'Akses ditolak oleh server API.',
                404 => 'Endpoint API tidak ditemukan.',
                422 => 'Data yang dikirim tidak dapat diproses.',
                429 => 'Terlalu banyak permintaan. Coba lagi nanti.',
                500 => 'Server API mengalami kesalahan internal.',
                502 => 'API Gateway error (Bad Gateway). Periksa koneksi ke server API.',
                503 => 'Server API tidak tersedia sementara.',
                504 => 'API Gateway timeout. Server terlalu lambat merespon.',
                0   => 'Tidak dapat terhubung ke server API.',
                default => "Server API merespon dengan kode HTTP {$statusCode}.",
            };
        }

        // Log ke Laravel log untuk debugging
        \Log::error('API Register Error', [
            'status'  => $statusCode,
            'message' => $message,
            'url'     => config('services.multipocket.base_url') . '/api/Multipocket/Register',
            'body'    => substr($body ?? '', 0, 500),
        ]);

        return ['status' => $statusCode, 'message' => $message];
    }

    public function index()
    {
        return view('register');
    }

    public function store(Request $request)
    {
        $request->validate([
            'firstName' => 'required|string|max:255',
            'lastName'  => 'required|string|max:255',
            'email'     => 'required|email',
            'phoneNo'   => 'required|string',
            'pin'       => 'required|min:6',
        ]);

        try {
            $client   = $this->makeClient();
            $baseUrl  = rtrim(config('services.multipocket.base_url'), '/');
            $endpoint = $baseUrl . '/api/Multipocket/Register';

            $payload = [
                'mid'           => config('services.multipocket.mid'),
                'merchantToken' => config('services.multipocket.merchant_token'),
                'firstName'     => $request->firstName,
                'lastName'      => $request->lastName,
                'email'         => $request->email,
                'phoneNo'       => $request->phoneNo,
                'pin'           => $request->pin,
            ];

            $response = $client->post($endpoint, [
                'json'    => $payload,
                'headers' => [
                    'Accept'       => 'application/json',
                    'Content-Type' => 'application/json',  // FIX: bukan json-patch+json
                ],
            ]);

            $data = json_decode($response->getBody()->getContents(), true);

            return redirect()
                ->route('activation.index', ['phoneNo' => $request->phoneNo])
                ->with('success', 'Registrasi berhasil! Silakan aktivasi akun Anda.');

        } catch (ConnectException $e) {
            \Log::error('Register ConnectException: ' . $e->getMessage());
            return back()->withErrors([
                'register' => 'Tidak dapat terhubung ke server API. Periksa koneksi internet VPS.',
            ])->withInput();

        } catch (RequestException $e) {
            $err = $this->parseError($e);
            return back()->withErrors([
                'register' => "Error {$err['status']}: {$err['message']}",
            ])->withInput();

        } catch (\Throwable $e) {
            \Log::error('Register Unexpected: ' . $e->getMessage());
            return back()->withErrors([
                'register' => 'Terjadi kesalahan tidak terduga: ' . $e->getMessage(),
            ])->withInput();
        }
    }
}
